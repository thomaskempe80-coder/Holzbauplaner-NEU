#include "chamfer/ChamferTool.h"
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp.hxx>
#include <TopTools_IndexedDataMapOfShapeListOfShape.hxx>
#include <TopTools_ListIteratorOfListOfShape.hxx>
#include <TopoDS.hxx>

namespace hbp::chamfer {
bool ChamferTool::Activate(const TopoDS_Shape& ownerShape, const TopoDS_Edge& edge) {
  Deactivate();
  if (ownerShape.IsNull() || edge.IsNull()) return false;
  sourceShape_ = ownerShape;
  edge_ = edge;
  active_ = true;
  return true;
}

void ChamferTool::Deactivate() noexcept {
  active_ = false;
  sourceShape_.Nullify();
  edge_.Nullify();
  finishedShape_.Nullify();
}

bool ChamferTool::CommitDistance(double distanceMm) {
  if (!active_ || sourceShape_.IsNull() || edge_.IsNull() || distanceMm <= 0.0) return false;

  TopTools_IndexedDataMapOfShapeListOfShape edgeFaces;
  TopExp::MapShapesAndAncestors(sourceShape_, TopAbs_EDGE, TopAbs_FACE, edgeFaces);
  if (!edgeFaces.Contains(edge_)) return false;

  const TopTools_ListOfShape& faces = edgeFaces.FindFromKey(edge_);
  if (faces.IsEmpty()) return false;
  const TopoDS_Face supportFace = TopoDS::Face(faces.First());

  BRepFilletAPI_MakeChamfer builder(sourceShape_);
  builder.Add(distanceMm, edge_, supportFace);
  builder.Build();
  if (!builder.IsDone()) return false;
  const TopoDS_Shape result = builder.Shape();
  if (result.IsNull()) return false;
  finishedShape_ = result;
  active_ = false;
  return true;
}

TopoDS_Shape ChamferTool::TakeFinishedShape() {
  TopoDS_Shape result = finishedShape_;
  finishedShape_.Nullify();
  return result;
}

std::wstring ChamferTool::StatusText() const {
  return active_ ? L"Fase: Maß in mm eingeben → Enter" : L"Fase";
}
}
