#include "offset/OffsetTool.h"

#include <BRepClass_FaceClassifier.hxx>
#include <BRepFeat_SplitShape.hxx>
#include <BRepOffsetAPI_MakeOffset.hxx>
#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <GeomAbs_JoinType.hxx>
#include <Precision.hxx>
#include <Standard_Failure.hxx>
#include <TopAbs_State.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Vertex.hxx>

#include <cmath>

namespace hbp::offset {

bool OffsetTool::Activate(const TopoDS_Shape& selectedFace, const TopoDS_Shape& ownerShape) {
  Deactivate();
  if (selectedFace.IsNull() || selectedFace.ShapeType() != TopAbs_FACE) return false;
  face_ = TopoDS::Face(selectedFace);
  ownerShape_ = ownerShape;
  sourceShape_ = ownerShape_.IsNull() ? selectedFace : ownerShape_;
  active_ = !face_.IsNull() && !sourceShape_.IsNull();
  return active_;
}

void OffsetTool::Deactivate() {
  active_ = false;
  face_.Nullify();
  ownerShape_.Nullify();
  sourceShape_.Nullify();
  offsetWire_.Nullify();
  finished_.Nullify();
}

bool OffsetTool::IsWireInsideFace(const TopoDS_Wire& wire) const {
  if (face_.IsNull() || wire.IsNull()) return false;
  int checked = 0;
  for (TopExp_Explorer ex(wire, TopAbs_VERTEX); ex.More(); ex.Next()) {
    const TopoDS_Vertex vertex = TopoDS::Vertex(ex.Current());
    const gp_Pnt p = BRep_Tool::Pnt(vertex);
    BRepClass_FaceClassifier classifier(face_, p, Precision::Confusion() * 20.0);
    const TopAbs_State state = classifier.State();
    if (state != TopAbs_IN && state != TopAbs_ON) return false;
    ++checked;
  }
  return checked >= 2;
}

bool OffsetTool::BuildInsetWire(double distanceMm, TopoDS_Wire& result) const {
  result.Nullify();
  if (face_.IsNull() || distanceMm <= Precision::Confusion()) return false;

  const TopoDS_Wire outer = BRepTools::OuterWire(face_);
  if (outer.IsNull()) return false;

  const double distances[2] = {std::abs(distanceMm), -std::abs(distanceMm)};
  for (const double signedDistance : distances) {
    try {
      BRepOffsetAPI_MakeOffset maker(outer, GeomAbs_Intersection, Standard_False);
      maker.Perform(signedDistance, Precision::Confusion());
      if (!maker.IsDone()) continue;

      const TopoDS_Shape offsetShape = maker.Shape();
      if (offsetShape.IsNull()) continue;

      TopoDS_Wire candidate;
      int wireCount = 0;
      for (TopExp_Explorer ex(offsetShape, TopAbs_WIRE); ex.More(); ex.Next()) {
        candidate = TopoDS::Wire(ex.Current());
        ++wireCount;
        if (wireCount > 1) break;
      }
      if (wireCount == 1 && !candidate.IsNull() && IsWireInsideFace(candidate)) {
        result = candidate;
        return true;
      }
    } catch (const Standard_Failure&) {
      // Invalid offset distance or degenerate contour: try the opposite direction.
    }
  }
  return false;
}

bool OffsetTool::SplitWithWire(const TopoDS_Wire& wire, TopoDS_Shape& result) const {
  result.Nullify();
  if (wire.IsNull() || face_.IsNull() || sourceShape_.IsNull()) return false;
  try {
    BRepFeat_SplitShape splitter(sourceShape_);
    splitter.Add(wire, face_);
    splitter.Build();
    if (!splitter.IsDone()) return false;
    result = splitter.Shape();
    return !result.IsNull();
  } catch (const Standard_Failure&) {
    return false;
  }
}

bool OffsetTool::CommitDistance(double distanceMm) {
  if (!active_ || distanceMm <= Precision::Confusion()) return false;
  TopoDS_Wire inset;
  if (!BuildInsetWire(distanceMm, inset)) return false;
  TopoDS_Shape split;
  if (!SplitWithWire(inset, split)) return false;
  offsetWire_ = inset;
  finished_ = split;
  active_ = false;
  return true;
}

TopoDS_Shape OffsetTool::TakeFinishedShape() {
  TopoDS_Shape result = finished_;
  finished_.Nullify();
  return result;
}

std::wstring OffsetTool::StatusText() const {
  if (!active_) return L"Versatz inaktiv";
  return L"Versatz: Abstand in mm eingeben → Enter";
}

}
