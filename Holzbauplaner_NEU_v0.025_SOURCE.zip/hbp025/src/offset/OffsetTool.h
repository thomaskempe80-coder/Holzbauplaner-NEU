#pragma once
#include <TopoDS_Face.hxx>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Wire.hxx>
#include <string>

namespace hbp::offset {
class OffsetTool {
public:
  bool Activate(const TopoDS_Shape& selectedFace, const TopoDS_Shape& ownerShape);
  void Deactivate();
  bool IsActive() const noexcept { return active_; }
  bool CommitDistance(double distanceMm);
  TopoDS_Shape TakeFinishedShape();
  const TopoDS_Shape& SourceShape() const noexcept { return sourceShape_; }
  const TopoDS_Wire& OffsetWire() const noexcept { return offsetWire_; }
  std::wstring StatusText() const;

private:
  bool BuildInsetWire(double distanceMm, TopoDS_Wire& result) const;
  bool IsWireInsideFace(const TopoDS_Wire& wire) const;
  bool SplitWithWire(const TopoDS_Wire& wire, TopoDS_Shape& result) const;

  bool active_ = false;
  TopoDS_Face face_;
  TopoDS_Shape ownerShape_;
  TopoDS_Shape sourceShape_;
  TopoDS_Wire offsetWire_;
  TopoDS_Shape finished_;
};
}
