#include "document-model/DocumentModel.h"
#include <algorithm>

namespace hbp::document {
bool DocumentModel::Initialize() {
  projectName_ = L"Unbenannt";
  undo_.clear();
  redo_.clear();
  return parts_.Initialize();
}

void DocumentModel::PushUndo() {
  undo_.push_back(CaptureState());
  if (undo_.size() > kHistoryLimit) undo_.erase(undo_.begin());
  redo_.clear();
}

void DocumentModel::AddShape(const TopoDS_Shape& shape) {
  if (shape.IsNull()) return;
  PushUndo();
  parts_.Add(shape);
}

bool DocumentModel::ReplaceShape(const TopoDS_Shape& oldShape, const TopoDS_Shape& newShape) {
  if (oldShape.IsNull() || newShape.IsNull() || !parts_.Contains(oldShape)) return false;
  PushUndo();
  if (parts_.ReplaceShape(oldShape, newShape)) return true;
  // Defensive rollback if replacement unexpectedly failed.
  RestoreState(undo_.back(), false);
  undo_.pop_back();
  return false;
}

bool DocumentModel::ContainsShape(const TopoDS_Shape& candidate) const {
  return parts_.Contains(candidate);
}

DocumentState DocumentModel::CaptureState() const {
  DocumentState state;
  state.projectName = projectName_;
  state.parts = parts_.CaptureState();
  return state;
}

void DocumentModel::RestoreState(const DocumentState& state, bool clearHistory) {
  projectName_ = state.projectName.empty() ? L"Unbenannt" : state.projectName;
  parts_.RestoreState(state.parts);
  if (clearHistory) ClearHistory();
}

void DocumentModel::ClearHistory() {
  undo_.clear();
  redo_.clear();
}

bool DocumentModel::Undo() {
  if (undo_.empty()) return false;
  redo_.push_back(CaptureState());
  const DocumentState state = undo_.back();
  undo_.pop_back();
  RestoreState(state, false);
  return true;
}

bool DocumentModel::Redo() {
  if (redo_.empty()) return false;
  undo_.push_back(CaptureState());
  if (undo_.size() > kHistoryLimit) undo_.erase(undo_.begin());
  const DocumentState state = redo_.back();
  redo_.pop_back();
  RestoreState(state, false);
  return true;
}

void DocumentModel::Shutdown() noexcept {
  ClearHistory();
  parts_.Shutdown();
  projectName_.clear();
}
}
