#pragma once
#include "core/IModule.h"
#include "parts/PartStore.h"
#include <string>
#include <TopoDS_Shape.hxx>
#include <vector>

namespace hbp::document {

struct DocumentState {
  std::wstring projectName;
  parts::PartStoreState parts;
};

class DocumentModel final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"document-model"; }
  bool Initialize() override;
  void Shutdown() noexcept override;
  const std::wstring& ProjectName() const noexcept { return projectName_; }

  void AddShape(const TopoDS_Shape& shape);
  bool ReplaceShape(const TopoDS_Shape& oldShape, const TopoDS_Shape& newShape);
  bool ContainsShape(const TopoDS_Shape& shape) const;
  std::vector<TopoDS_Shape> Shapes() const { return parts_.Shapes(); }

  parts::PartStore& Parts() noexcept { return parts_; }
  const parts::PartStore& Parts() const noexcept { return parts_; }
  const parts::PartRecord* FindPart(const TopoDS_Shape& shape) const { return parts_.Find(shape); }

  DocumentState CaptureState() const;
  void RestoreState(const DocumentState& state, bool clearHistory = false);
  void ClearHistory();
  bool CanUndo() const noexcept { return !undo_.empty(); }
  bool CanRedo() const noexcept { return !redo_.empty(); }
  bool Undo();
  bool Redo();

private:
  void PushUndo();

  std::wstring projectName_;
  parts::PartStore parts_;
  std::vector<DocumentState> undo_;
  std::vector<DocumentState> redo_;
  static constexpr std::size_t kHistoryLimit = 100;
};
}
