#pragma once
#include <TopoDS_Face.hxx>
#include <TopoDS_Shape.hxx>
#include <string>

namespace hbp::pushpull {
class PushPullTool {
public:
  void Activate(const TopoDS_Shape& selectedFace, const TopoDS_Shape& ownerShape);
  void Deactivate();
  bool IsActive() const noexcept { return active_; }
  bool HasFace() const noexcept { return !face_.IsNull(); }
  bool CommitDistance(double distanceMm);
  TopoDS_Shape TakeFinishedShape();
  const TopoDS_Shape& SourceShape() const noexcept { return sourceShape_; }
  std::wstring StatusText() const;
private:
  bool active_ = false;
  TopoDS_Shape sourceShape_;
  TopoDS_Shape ownerShape_;
  TopoDS_Face face_;
  TopoDS_Shape finished_;
};
}
