#include "push-pull/PushPullTool.h"
#include <BRep_Tool.hxx>
#include <BRepTools.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <Geom_Surface.hxx>
#include <GeomLProp_SLProps.hxx>
#include <TopAbs_Orientation.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopoDS.hxx>
#include <gp_Dir.hxx>
#include <gp_Vec.hxx>
#include <cmath>

namespace hbp::pushpull {
void PushPullTool::Activate(const TopoDS_Shape& selectedFace, const TopoDS_Shape& ownerShape) {
  active_ = true;
  finished_.Nullify();
  ownerShape_ = ownerShape;
  sourceShape_ = ownerShape.IsNull() ? selectedFace : ownerShape;
  face_.Nullify();
  if (!selectedFace.IsNull() && selectedFace.ShapeType() == TopAbs_FACE) {
    face_ = TopoDS::Face(selectedFace);
  }
}

void PushPullTool::Deactivate() {
  active_ = false;
  sourceShape_.Nullify();
  ownerShape_.Nullify();
  face_.Nullify();
  finished_.Nullify();
}

bool PushPullTool::CommitDistance(double distanceMm) {
  if (!active_ || face_.IsNull() || std::abs(distanceMm) < 1.0e-9) return false;

  Standard_Real uMin=0.0, uMax=0.0, vMin=0.0, vMax=0.0;
  BRepTools::UVBounds(face_, uMin, uMax, vMin, vMax);
  Handle(Geom_Surface) surface = BRep_Tool::Surface(face_);
  if (surface.IsNull()) return false;

  GeomLProp_SLProps props(surface, 0.5*(uMin+uMax), 0.5*(vMin+vMax), 1, 1.0e-7);
  if (!props.IsNormalDefined()) return false;
  gp_Dir normal = props.Normal();
  if (face_.Orientation() == TopAbs_REVERSED) normal.Reverse();

  try {
    gp_Vec vector(normal);
    vector *= distanceMm;
    BRepPrimAPI_MakePrism prismBuilder(face_, vector, Standard_False, Standard_True);
    prismBuilder.Build();
    if (!prismBuilder.IsDone()) return false;
    const TopoDS_Shape prism = prismBuilder.Shape();
    if (prism.IsNull()) return false;

    const bool modifiesExistingBody = !ownerShape_.IsNull() && !ownerShape_.IsSame(face_)
      && ownerShape_.ShapeType() != TopAbs_FACE;

    if (modifiesExistingBody) {
      if (distanceMm > 0.0) {
        BRepAlgoAPI_Fuse op(ownerShape_, prism);
        op.Build();
        if (!op.IsDone()) return false;
        finished_ = op.Shape();
      } else {
        BRepAlgoAPI_Cut op(ownerShape_, prism);
        op.Build();
        if (!op.IsDone()) return false;
        finished_ = op.Shape();
      }
    } else {
      finished_ = prism;
      sourceShape_ = face_;
    }
    return !finished_.IsNull();
  } catch (...) {
    finished_.Nullify();
    return false;
  }
}

TopoDS_Shape PushPullTool::TakeFinishedShape() {
  TopoDS_Shape out = finished_;
  finished_.Nullify();
  if (!out.IsNull()) {
    active_ = false;
    face_.Nullify();
  }
  return out;
}

std::wstring PushPullTool::StatusText() const {
  if (!active_) return L"Push/Pull inaktiv";
  if (face_.IsNull()) return L"Push/Pull: zuerst eine Fläche auswählen";
  return L"Push/Pull aktiv • +mm herausziehen • -mm hineindrücken";
}
}
