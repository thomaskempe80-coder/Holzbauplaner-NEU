#pragma once
#include <windows.h>
#include "viewer/OcctViewer.h"
#include "part-drawing/PartDrawing.h"
#include "sheet-cutting/SheetCutting.h"
#include "bar-cutting/BarCutting.h"
#include "cutting/CutTypes.h"
#include "save-load/ProjectFile.h"
#include <string>

namespace hbp::ui {
class MainWindow {
public:
  bool Create(HINSTANCE instance, int showCommand, document::DocumentModel* document);
  int Run();

private:
  static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
  static LRESULT CALLBACK ViewportProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
  LRESULT HandleMessage(UINT msg, WPARAM wp, LPARAM lp);
  LRESULT HandleViewportMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
  void Layout();
  void Paint(HDC dc);
  void DrawToolbar(HDC dc);
  void DrawLeftTools(HDC dc);
  void DrawRightPanel(HDC dc);
  void DrawPartDrawing(HDC dc);
  void DrawCutting(HDC dc);
  void CreateViewport();
  void ActivateToolFromSidebar(int x, int y);
  bool HandleRightPanelClick(int x, int y);
  bool HandleToolbarClick(int x, int y);
  bool SaveProject(bool saveAs = false);
  bool OpenProject();
  bool UndoProject();
  bool RedoProject();
  void HandleNumericChar(wchar_t ch);
  bool CommitNumericRectangle();
  bool CommitNumericCircle();
  bool CommitNumericPushPull();
  bool CommitNumericOffset();
  bool CommitNumericChamfer();
  bool CommitNumericFillet();

  HINSTANCE instance_ = nullptr;
  HCURSOR pencilCursor_ = nullptr;
  HCURSOR eraserCursor_ = nullptr;
  document::DocumentModel* document_ = nullptr;
  HWND hwnd_ = nullptr;
  HWND viewportHwnd_ = nullptr;
  bool orbiting_ = false;
  bool panning_ = false;
  viewer::OcctViewer viewer_;
  std::wstring numericInput_;
  part_drawing::PartDrawing partDrawing_;
  part_drawing::DrawingSheet drawingSheet_;
  bool partDrawingOpen_ = false;
  sheet_cutting::SheetCutting sheetCutting_;
  bar_cutting::BarCutting barCutting_;
  std::vector<cutting::CutItem> sheetCuts_;
  std::vector<cutting::CutItem> barCuts_;
  bool cuttingOpen_ = false;
  save_load::ProjectFile projectFile_;
  std::wstring projectPath_;
  std::wstring uiMessage_;
};
}
