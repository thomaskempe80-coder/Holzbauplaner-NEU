#pragma once
#include <windows.h>

namespace hbp::ui {
struct UiTheme {
  static constexpr COLORREF Background = RGB(255,255,255);
  static constexpr COLORREF Panel = RGB(247,248,250);
  static constexpr COLORREF PanelBorder = RGB(222,226,230);
  static constexpr COLORREF Text = RGB(32,36,42);
  static constexpr COLORREF MutedText = RGB(103,110,120);
  static constexpr COLORREF Button = RGB(255,255,255);
  static constexpr COLORREF ButtonHover = RGB(238,242,247);
  static constexpr COLORREF ButtonActive = RGB(228,238,250);
  static constexpr COLORREF Accent = RGB(45,105,175);
  static constexpr COLORREF AccentSoft = RGB(205,222,241);
};
}
