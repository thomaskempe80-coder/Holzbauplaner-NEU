#include "ui/MainWindow.h"
#include "ui/UiTheme.h"
#include "app/Version.h"
#include <string>
#include <array>
#include <windowsx.h>
#include <cwctype>
#include <cstdlib>
#include <cwchar>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <commdlg.h>

namespace {
constexpr int kTopBar = 58;
constexpr int kLeftBar = 76;
constexpr int kRightPanel = 286;
constexpr int kStatusBar = 26;
constexpr wchar_t kClassName[] = L"HolzbauplanerMainWindow";
constexpr wchar_t kViewportClassName[] = L"HolzbauplanerOcctViewport";

void Fill(HDC dc, const RECT& r, COLORREF color) {
  HBRUSH brush = CreateSolidBrush(color);
  FillRect(dc, &r, brush);
  DeleteObject(brush);
}

void Text(HDC dc, int x, int y, const wchar_t* value, COLORREF color, int height = 16, int weight = FW_NORMAL) {
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc, color);
  HFONT font = CreateFontW(-height,0,0,0,weight,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,FF_DONTCARE,L"Segoe UI");
  HGDIOBJ old = SelectObject(dc, font);
  TextOutW(dc, x, y, value, static_cast<int>(wcslen(value)));
  SelectObject(dc, old);
  DeleteObject(font);
}


HCURSOR CreatePencilCursor(HINSTANCE instance) {
  constexpr int w = 32;
  constexpr int h = 32;
  constexpr int bytesPerRow = w / 8;
  std::array<BYTE, bytesPerRow * h> andMask{};
  std::array<BYTE, bytesPerRow * h> xorMask{};
  andMask.fill(0xFF); // transparent by default
  xorMask.fill(0x00);

  auto blackPixel = [&](int x, int y) {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    const int index = y * bytesPerRow + x / 8;
    const BYTE bit = static_cast<BYTE>(0x80u >> (x % 8));
    andMask[index] = static_cast<BYTE>(andMask[index] & ~bit);
  };

  // Kleine diagonale Bleistift-Silhouette; Hotspot liegt an der Spitze links unten.
  for (int i = 0; i < 20; ++i) {
    const int x = 3 + i;
    const int y = 27 - i;
    blackPixel(x, y);
    blackPixel(x + 1, y);
    blackPixel(x, y - 1);
  }
  blackPixel(2, 28);
  blackPixel(3, 28);
  blackPixel(24, 6);
  blackPixel(25, 5);
  blackPixel(25, 6);

  return CreateCursor(instance, 2, 28, w, h, andMask.data(), xorMask.data());
}

HCURSOR CreateEraserCursor(HINSTANCE instance) {
  constexpr int w = 32;
  constexpr int h = 32;
  constexpr int bytesPerRow = w / 8;
  std::array<BYTE, bytesPerRow * h> andMask{};
  std::array<BYTE, bytesPerRow * h> xorMask{};
  andMask.fill(0xFF);
  xorMask.fill(0x00);

  auto blackPixel = [&](int x, int y) {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    const int index = y * bytesPerRow + x / 8;
    const BYTE bit = static_cast<BYTE>(0x80u >> (x % 8));
    andMask[index] = static_cast<BYTE>(andMask[index] & ~bit);
  };

  // Schräger Radiergummi; Hotspot an der linken unteren Löschkante.
  for (int y = 10; y <= 23; ++y) {
    for (int x = 8; x <= 22; ++x) {
      const int skew = (23 - y) / 3;
      if (x >= 8 + skew && x <= 20 + skew) blackPixel(x, y);
    }
  }
  for (int x = 7; x <= 16; ++x) blackPixel(x, 24);
  return CreateCursor(instance, 8, 24, w, h, andMask.data(), xorMask.data());
}

void Button(HDC dc, RECT r, const wchar_t* label, bool active = false) {
  HBRUSH brush = CreateSolidBrush(active ? hbp::ui::UiTheme::ButtonActive : hbp::ui::UiTheme::Button);
  HPEN pen = CreatePen(PS_SOLID, active ? 2 : 1, active ? hbp::ui::UiTheme::Accent : hbp::ui::UiTheme::PanelBorder);
  HGDIOBJ oldBrush = SelectObject(dc, brush);
  HGDIOBJ oldPen = SelectObject(dc, pen);
  RoundRect(dc,r.left,r.top,r.right,r.bottom,10,10);
  SelectObject(dc, oldPen); SelectObject(dc, oldBrush);
  DeleteObject(pen); DeleteObject(brush);
  SIZE s{};
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc,hbp::ui::UiTheme::Text);
  HFONT font = CreateFontW(-15,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,FF_DONTCARE,L"Segoe UI");
  HGDIOBJ oldFont=SelectObject(dc,font);
  GetTextExtentPoint32W(dc,label,static_cast<int>(wcslen(label)),&s);
  TextOutW(dc,r.left+(r.right-r.left-s.cx)/2,r.top+(r.bottom-r.top-s.cy)/2,label,static_cast<int>(wcslen(label)));
  SelectObject(dc,oldFont); DeleteObject(font);
}
}

namespace hbp::ui {
bool MainWindow::Create(HINSTANCE instance, int showCommand, document::DocumentModel* document) {
  instance_ = instance;
  document_ = document;
  pencilCursor_ = CreatePencilCursor(instance_);
  eraserCursor_ = CreateEraserCursor(instance_);
  partDrawing_.Initialize();
  projectFile_.Initialize();
  WNDCLASSEXW wc{sizeof(wc)};
  wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
  wc.lpfnWndProc = &MainWindow::WindowProc;
  wc.hInstance = instance_;
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  wc.lpszClassName = kClassName;
  if (!RegisterClassExW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;

  WNDCLASSEXW viewClass{sizeof(viewClass)};
  viewClass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
  viewClass.lpfnWndProc = &MainWindow::ViewportProc;
  viewClass.hInstance = instance_;
  viewClass.hCursor = LoadCursor(nullptr, IDC_ARROW);
  viewClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  viewClass.lpszClassName = kViewportClassName;
  if (!RegisterClassExW(&viewClass) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;

  std::wstring title = std::wstring(app::kProductName) + L"  •  v" + app::kVersion;
  hwnd_ = CreateWindowExW(0,kClassName,title.c_str(),WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT,CW_USEDEFAULT,1440,900,nullptr,nullptr,instance_,this);
  if (!hwnd_) return false;
  ShowWindow(hwnd_, showCommand);
  UpdateWindow(hwnd_);
  return true;
}

int MainWindow::Run() {
  MSG msg{};
  while (GetMessageW(&msg,nullptr,0,0) > 0) {
    TranslateMessage(&msg);
    DispatchMessageW(&msg);
  }
  return static_cast<int>(msg.wParam);
}

LRESULT CALLBACK MainWindow::WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  MainWindow* self = nullptr;
  if (msg == WM_NCCREATE) {
    auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
    self = static_cast<MainWindow*>(cs->lpCreateParams);
    self->hwnd_ = hwnd;
    SetWindowLongPtrW(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(self));
  } else {
    self = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd,GWLP_USERDATA));
  }
  return self ? self->HandleMessage(msg,wp,lp) : DefWindowProcW(hwnd,msg,wp,lp);
}

LRESULT CALLBACK MainWindow::ViewportProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  MainWindow* self = nullptr;
  if (msg == WM_NCCREATE) {
    auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
    self = static_cast<MainWindow*>(cs->lpCreateParams);
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
  } else {
    self = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
  }
  return self ? self->HandleViewportMessage(hwnd, msg, wp, lp) : DefWindowProcW(hwnd, msg, wp, lp);
}

LRESULT MainWindow::HandleViewportMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  const int x = GET_X_LPARAM(lp);
  const int y = GET_Y_LPARAM(lp);
  switch (msg) {
    case WM_RBUTTONDOWN:
      orbiting_ = true;
      SetCapture(hwnd);
      viewer_.BeginOrbit(x, y);
      return 0;
    case WM_RBUTTONUP:
      orbiting_ = false;
      if (!panning_) ReleaseCapture();
      return 0;
    case WM_MBUTTONDOWN:
      panning_ = true;
      SetCapture(hwnd);
      viewer_.BeginPan(x, y);
      return 0;
    case WM_MBUTTONUP:
      panning_ = false;
      if (!orbiting_) ReleaseCapture();
      return 0;
    case WM_LBUTTONDOWN:
      if (!orbiting_ && !panning_) {
        viewer_.LeftClickAt(x, y);
        numericInput_.clear();
        InvalidateRect(hwnd_, nullptr, FALSE);
      }
      return 0;
    case WM_MOUSEMOVE:
      if (orbiting_) viewer_.OrbitTo(x, y);
      else if (panning_) viewer_.PanTo(x, y);
      else {
        viewer_.HoverAt(x, y);
        InvalidateRect(hwnd_, nullptr, FALSE);
      }
      return 0;
    case WM_MOUSEWHEEL: {
      POINT p{GET_X_LPARAM(lp), GET_Y_LPARAM(lp)};
      ScreenToClient(hwnd, &p);
      viewer_.ZoomWheel(p.x, p.y, GET_WHEEL_DELTA_WPARAM(wp));
      return 0;
    }
    case WM_CHAR:
      HandleNumericChar(static_cast<wchar_t>(wp));
      return 0;
    case WM_KEYDOWN:
      if (GetKeyState(VK_CONTROL) & 0x8000) {
        if (wp == 'S') { SaveProject(false); return 0; }
        if (wp == 'O') { OpenProject(); return 0; }
        if (wp == 'Z') { UndoProject(); return 0; }
        if (wp == 'Y') { RedoProject(); return 0; }
      }
      if (wp == VK_ESCAPE) {
        viewer_.CancelActiveTool();
        numericInput_.clear();
        InvalidateRect(hwnd_, nullptr, FALSE);
        return 0;
      }
      return 0;
    case WM_SETCURSOR:
      if (viewer_.ConstructionLineActive() || viewer_.MeasureActive() || viewer_.AngleActive()) {
        SetCursor(LoadCursor(nullptr, IDC_CROSS));
        return TRUE;
      }
      if (viewer_.ChamferActive() || viewer_.FilletActive()) {
        SetCursor(LoadCursor(nullptr, IDC_CROSS));
        return TRUE;
      }
      if (viewer_.DeleteActive()) {
        SetCursor(eraserCursor_ ? eraserCursor_ : LoadCursor(nullptr, IDC_NO));
        return TRUE;
      }
      if (viewer_.PushPullActive()) {
        SetCursor(LoadCursor(nullptr, IDC_SIZENS));
        return TRUE;
      }
      if (viewer_.OffsetActive()) {
        SetCursor(LoadCursor(nullptr, IDC_SIZEALL));
        return TRUE;
      }
      if (viewer_.PencilActive()) {
        SetCursor(pencilCursor_ ? pencilCursor_ : LoadCursor(nullptr, IDC_CROSS));
        return TRUE;
      }
      if (viewer_.RectangleActive() || viewer_.CircleActive() || viewer_.ArcActive()) {
        SetCursor(LoadCursor(nullptr, IDC_CROSS));
        return TRUE;
      }
      break;
    case WM_SIZE:
      viewer_.Resize();
      return 0;
    case WM_ERASEBKGND:
      return 1;
    default:
      return DefWindowProcW(hwnd, msg, wp, lp);
  }
}

LRESULT MainWindow::HandleMessage(UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_CREATE: CreateViewport(); return 0;
    case WM_SIZE: Layout(); viewer_.Resize(); return 0;
    case WM_LBUTTONDOWN: {
      const int x = GET_X_LPARAM(lp);
      const int y = GET_Y_LPARAM(lp);
      if (!HandleToolbarClick(x, y) && !HandleRightPanelClick(x, y)) ActivateToolFromSidebar(x, y);
      return 0;
    }
    case WM_KEYDOWN:
      if (GetKeyState(VK_CONTROL) & 0x8000) {
        if (wp == 'S') { SaveProject(false); return 0; }
        if (wp == 'O') { OpenProject(); return 0; }
        if (wp == 'Z') { UndoProject(); return 0; }
        if (wp == 'Y') { RedoProject(); return 0; }
      }
      break;
    case WM_PAINT: {
      PAINTSTRUCT ps{}; HDC dc = BeginPaint(hwnd_,&ps); Paint(dc); EndPaint(hwnd_,&ps); return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_DESTROY:
      viewer_.Detach();
      partDrawing_.Shutdown();
      projectFile_.Shutdown();
      if (pencilCursor_) { DestroyCursor(pencilCursor_); pencilCursor_ = nullptr; }
      if (eraserCursor_) { DestroyCursor(eraserCursor_); eraserCursor_ = nullptr; }
      PostQuitMessage(0);
      return 0;
    default: return DefWindowProcW(hwnd_,msg,wp,lp);
  }
  return DefWindowProcW(hwnd_,msg,wp,lp);
}

void MainWindow::CreateViewport() {
  viewportHwnd_ = CreateWindowExW(0,kViewportClassName,L"",WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
      0,0,100,100,hwnd_,nullptr,instance_,this);
  Layout();
  viewer_.Attach(viewportHwnd_, document_);
}

void MainWindow::Layout() {
  if (!hwnd_ || !viewportHwnd_) return;
  RECT client{}; GetClientRect(hwnd_,&client);
  const int width = client.right;
  const int height = client.bottom;
  const int x = kLeftBar;
  const int y = kTopBar;
  const int w = (width - kLeftBar - kRightPanel) > 1 ? width-kLeftBar-kRightPanel : 1;
  const int h = (height-kTopBar-kStatusBar) > 1 ? height-kTopBar-kStatusBar : 1;
  MoveWindow(viewportHwnd_,x,y,w,h,TRUE);
  ShowWindow(viewportHwnd_, (partDrawingOpen_ || cuttingOpen_) ? SW_HIDE : SW_SHOW);
}

void MainWindow::Paint(HDC dc) {
  RECT client{}; GetClientRect(hwnd_,&client);
  Fill(dc,client,UiTheme::Background);
  DrawToolbar(dc); DrawLeftTools(dc); DrawRightPanel(dc);
  if (partDrawingOpen_) DrawPartDrawing(dc);
  if (cuttingOpen_) DrawCutting(dc);

  RECT status{0,client.bottom-kStatusBar,client.right,client.bottom};
  Fill(dc,status,UiTheme::Panel);
  std::wstring statusText = viewer_.ActiveToolStatus();
  if (!numericInput_.empty()) statusText += L"  •  Eingabe: " + numericInput_;
  if (viewer_.ExplodedViewEnabled()) statusText += L"  •  EXPLOSION AN";
  if (partDrawingOpen_) statusText += L"  •  BAUTEILZEICHNUNG";
  if (cuttingOpen_) statusText += L"  •  ZUSCHNITT";
  if (!uiMessage_.empty()) statusText += L"  •  " + uiMessage_;
  statusText += L"  •  RMB Orbit  •  MMB Pan  •  Mausrad Zoom  •  ESC Abbruch  •  v0.025";
  Text(dc,12,status.top+5,statusText.c_str(),UiTheme::MutedText,14);
}

void MainWindow::DrawToolbar(HDC dc) {
  RECT client{}; GetClientRect(hwnd_,&client);
  RECT bar{0,0,client.right,kTopBar}; Fill(dc,bar,UiTheme::Panel);
  Text(dc,18,17,L"HOLZBAUPLANER",UiTheme::Text,18,FW_BOLD);
  Text(dc,166,20,L"NEU · v0.025",UiTheme::MutedText,14,FW_SEMIBOLD);

  const std::array<const wchar_t*,7> items{
    L"Speichern", L"Öffnen", document_ && document_->CanUndo() ? L"Undo •" : L"Undo",
    document_ && document_->CanRedo() ? L"Redo •" : L"Redo",
    viewer_.ExplodedViewEnabled() ? L"Explosion: AN" : L"Explosion",
    partDrawingOpen_ ? L"Bauplan: AN" : L"Baupläne",
    cuttingOpen_ ? L"Zuschnitt: AN" : L"Zuschnitt"};
  int x = 286;
  for (size_t i = 0; i < items.size(); ++i) {
    RECT r{x,10,x+102,48};
    const bool active = (i == 4 && viewer_.ExplodedViewEnabled()) || (i == 5 && partDrawingOpen_) || (i == 6 && cuttingOpen_);
    Button(dc,r,items[i],active);
    x += 108;
  }
}

void MainWindow::DrawLeftTools(HDC dc) {
  RECT client{}; GetClientRect(hwnd_,&client);
  RECT panel{0,kTopBar,kLeftBar,client.bottom-kStatusBar}; Fill(dc,panel,UiTheme::Panel);
  const std::array<const wchar_t*,13> tools{L"Auswahl",L"Rechteck",L"Kreis",L"Bleistift",L"Bogen",L"Push/Pull",L"Versatz",L"Löschen",L"Fase",L"Rundung",L"Hilfslinie",L"Messen",L"Winkel"};
  const std::array<bool,13> active{
    viewer_.SelectionActive(), viewer_.RectangleActive(), viewer_.CircleActive(), viewer_.PencilActive(), viewer_.ArcActive(),
    viewer_.PushPullActive(), viewer_.OffsetActive(), viewer_.DeleteActive(), viewer_.ChamferActive(), viewer_.FilletActive(),
    viewer_.ConstructionLineActive(), viewer_.MeasureActive(), viewer_.AngleActive()};
  int y = kTopBar + 10;
  for (size_t i = 0; i < tools.size(); ++i) {
    RECT r{8,y,kLeftBar-8,y+32}; Button(dc,r,active[i] ? L"●" : L"•",active[i]);
    Text(dc,5,y+35,tools[i],active[i] ? UiTheme::Accent : UiTheme::MutedText,10,active[i] ? FW_SEMIBOLD : FW_NORMAL);
    y += 57;
  }
}

void MainWindow::DrawRightPanel(HDC dc) {
  RECT client{}; GetClientRect(hwnd_,&client);
  RECT panel{client.right-kRightPanel,kTopBar,client.right,client.bottom-kStatusBar}; Fill(dc,panel,UiTheme::Panel);
  Text(dc,panel.left+20,panel.top+20,L"Eigenschaften",UiTheme::Text,18,FW_BOLD);
  Text(dc,panel.left+20,panel.top+55,viewer_.CurrentSelection().label.c_str(),UiTheme::MutedText,14);

  const auto& selection = viewer_.CurrentSelection();
  TopoDS_Shape owner = selection.ownerShape.IsNull() ? selection.shape : selection.ownerShape;
  const parts::PartRecord* part = (document_ && !owner.IsNull()) ? document_->FindPart(owner) : nullptr;
  if (part) {
    Text(dc,panel.left+20,panel.top+82,(part->name + L"  ·  " + part->id).c_str(),UiTheme::Text,14,FW_SEMIBOLD);
    Text(dc,panel.left+20,panel.top+106,(L"Typ: " + part->type).c_str(),UiTheme::MutedText,12);
    std::wostringstream dims;
    dims << std::fixed << std::setprecision(1)
         << L"Maße: " << part->dimensions.xMm << L" × "
         << part->dimensions.yMm << L" × " << part->dimensions.zMm << L" mm";
    Text(dc,panel.left+20,panel.top+126,dims.str().c_str(),UiTheme::MutedText,12);
  } else {
    Text(dc,panel.left+20,panel.top+82,L"Kein Projektbauteil gewählt",UiTheme::MutedText,12);
  }

  Text(dc,panel.left+20,panel.top+164,L"Aktives Werkzeug",UiTheme::Text,15,FW_SEMIBOLD);
  Text(dc,panel.left+20,panel.top+193,viewer_.ActiveToolStatus().c_str(),UiTheme::Accent,14,FW_SEMIBOLD);
  Text(dc,panel.left+20,panel.top+229,L"Ansicht",UiTheme::Text,15,FW_SEMIBOLD);

  std::wstring gridLabel = viewer_.GridVisible() ? L"Raster: AN" : L"Raster: AUS";
  std::wstring xrayLabel = viewer_.XRayEnabled() ? L"Röntgen: AN" : L"Röntgen: AUS";
  std::wstring refLabel = L"Referenz: " + viewer_.ReferenceModeLabel();
  Button(dc, RECT{panel.left+20,panel.top+258,panel.right-20,panel.top+294}, gridLabel.c_str());
  Button(dc, RECT{panel.left+20,panel.top+302,panel.right-20,panel.top+338}, xrayLabel.c_str());
  Button(dc, RECT{panel.left+20,panel.top+346,panel.right-20,panel.top+382}, refLabel.c_str());

  Text(dc,panel.left+20,panel.top+414,L"Material & Optik",UiTheme::Text,15,FW_SEMIBOLD);
  Text(dc,panel.left+20,panel.top+445,part ? part->material.c_str() : L"Holzarten folgen im Materialmodul",UiTheme::MutedText,13);
  Text(dc,panel.left+20,panel.top+480,L"Fang / Inference",UiTheme::Text,15,FW_SEMIBOLD);
  Text(dc,panel.left+20,panel.top+509,viewer_.CurrentSnap().label.c_str(),UiTheme::MutedText,13);
}


void MainWindow::DrawPartDrawing(HDC dc) {
  RECT client{}; GetClientRect(hwnd_, &client);
  RECT area{kLeftBar, kTopBar, client.right-kRightPanel, client.bottom-kStatusBar};
  Fill(dc, area, RGB(232,235,238));

  const int margin = 26;
  RECT page{area.left+margin, area.top+margin, area.right-margin, area.bottom-margin};
  Fill(dc, page, RGB(255,255,255));
  HPEN borderPen = CreatePen(PS_SOLID,1,RGB(190,194,198));
  HGDIOBJ oldPen = SelectObject(dc,borderPen);
  HGDIOBJ oldBrush = SelectObject(dc,GetStockObject(NULL_BRUSH));
  Rectangle(dc,page.left,page.top,page.right,page.bottom);
  SelectObject(dc,oldBrush); SelectObject(dc,oldPen); DeleteObject(borderPen);

  Text(dc,page.left+24,page.top+18,L"BAUTEILZEICHNUNG",UiTheme::Text,20,FW_BOLD);
  std::wstring meta = drawingSheet_.partName + L"  ·  " + drawingSheet_.partId;
  Text(dc,page.left+24,page.top+48,meta.c_str(),UiTheme::MutedText,14,FW_SEMIBOLD);
  std::wostringstream dimText;
  dimText << std::fixed << std::setprecision(1)
          << L"Außenmaße: " << drawingSheet_.dimensions.xMm << L" × "
          << drawingSheet_.dimensions.yMm << L" × " << drawingSheet_.dimensions.zMm << L" mm";
  Text(dc,page.left+24,page.top+69,dimText.str().c_str(),UiTheme::MutedText,13);

  const int viewsTop = page.top + 105;
  const int viewsBottom = page.bottom - 72;
  const int gap = 18;
  const int usableW = page.right-page.left-48;
  const int cellW = (usableW - gap*2) / 3;
  const int cellH = std::max(120, viewsBottom-viewsTop);

  for (size_t i=0; i<drawingSheet_.views.size() && i<3; ++i) {
    const auto& view = drawingSheet_.views[i];
    RECT cell{page.left+24+static_cast<int>(i)*(cellW+gap), viewsTop,
              page.left+24+static_cast<int>(i)*(cellW+gap)+cellW, viewsTop+cellH};
    HPEN cellPen = CreatePen(PS_SOLID,1,RGB(220,223,226));
    oldPen = SelectObject(dc,cellPen); oldBrush=SelectObject(dc,GetStockObject(NULL_BRUSH));
    Rectangle(dc,cell.left,cell.top,cell.right,cell.bottom);
    SelectObject(dc,oldBrush); SelectObject(dc,oldPen); DeleteObject(cellPen);
    Text(dc,cell.left+10,cell.top+8,view.title.c_str(),UiTheme::Text,14,FW_SEMIBOLD);

    double minX=0.0,maxX=0.0,minY=0.0,maxY=0.0;
    bool have=false;
    for (const auto& seg : view.segments) {
      for (const auto& pt : {seg.a, seg.b}) {
        if (!have) { minX=maxX=pt.x; minY=maxY=pt.y; have=true; }
        else { minX=std::min(minX,pt.x); maxX=std::max(maxX,pt.x); minY=std::min(minY,pt.y); maxY=std::max(maxY,pt.y); }
      }
    }
    const double spanX=std::max(1e-6,maxX-minX);
    const double spanY=std::max(1e-6,maxY-minY);
    const int plotLeft=cell.left+34, plotRight=cell.right-20;
    const int plotTop=cell.top+48, plotBottom=cell.bottom-46;
    const double scale=std::min((plotRight-plotLeft)/spanX,(plotBottom-plotTop)/spanY)*0.88;
    const double usedW=spanX*scale, usedH=spanY*scale;
    const double ox=plotLeft+((plotRight-plotLeft)-usedW)/2.0-minX*scale;
    const double oy=plotTop+((plotBottom-plotTop)-usedH)/2.0+maxY*scale;

    HPEN shapePen=CreatePen(PS_SOLID,1,RGB(25,29,33));
    oldPen=SelectObject(dc,shapePen);
    for (const auto& seg:view.segments) {
      int x1=static_cast<int>(std::lround(ox+seg.a.x*scale));
      int y1=static_cast<int>(std::lround(oy-seg.a.y*scale));
      int x2=static_cast<int>(std::lround(ox+seg.b.x*scale));
      int y2=static_cast<int>(std::lround(oy-seg.b.y*scale));
      MoveToEx(dc,x1,y1,nullptr); LineTo(dc,x2,y2);
    }
    SelectObject(dc,oldPen); DeleteObject(shapePen);

    std::wostringstream dims;
    dims << std::fixed << std::setprecision(1) << view.widthMm << L" × " << view.heightMm << L" mm";
    Text(dc,cell.left+10,cell.bottom-29,dims.str().c_str(),UiTheme::MutedText,12);
  }

  RECT titleBox{page.left+24,page.bottom-57,page.right-24,page.bottom-20};
  HPEN titlePen=CreatePen(PS_SOLID,1,RGB(180,184,188));
  oldPen=SelectObject(dc,titlePen); oldBrush=SelectObject(dc,GetStockObject(NULL_BRUSH));
  Rectangle(dc,titleBox.left,titleBox.top,titleBox.right,titleBox.bottom);
  SelectObject(dc,oldBrush); SelectObject(dc,oldPen); DeleteObject(titlePen);
  Text(dc,titleBox.left+10,titleBox.top+7,L"Holzbauplaner · technische Grundansichten · Maßangaben in mm",UiTheme::MutedText,12);
}


void MainWindow::DrawCutting(HDC dc) {
  RECT client{}; GetClientRect(hwnd_, &client);
  RECT area{kLeftBar, kTopBar, client.right-kRightPanel, client.bottom-kStatusBar};
  Fill(dc, area, RGB(232,235,238));

  const int margin = 26;
  RECT page{area.left+margin, area.top+margin, area.right-margin, area.bottom-margin};
  Fill(dc, page, RGB(255,255,255));
  HPEN borderPen = CreatePen(PS_SOLID,1,RGB(190,194,198));
  HGDIOBJ oldPen = SelectObject(dc,borderPen);
  HGDIOBJ oldBrush = SelectObject(dc,GetStockObject(NULL_BRUSH));
  Rectangle(dc,page.left,page.top,page.right,page.bottom);
  SelectObject(dc,oldBrush); SelectObject(dc,oldPen); DeleteObject(borderPen);

  Text(dc,page.left+24,page.top+18,L"ZUSCHNITT",UiTheme::Text,20,FW_BOLD);
  Text(dc,page.left+24,page.top+48,L"Direkt aus den echten Bauteilen des PartStore · Maße in mm",UiTheme::MutedText,13);

  const int gap = 20;
  const int boxTop = page.top + 84;
  const int boxBottom = page.bottom - 28;
  const int half = (page.right-page.left-48-gap)/2;
  RECT sheetBox{page.left+24,boxTop,page.left+24+half,boxBottom};
  RECT barBox{sheetBox.right+gap,boxTop,page.right-24,boxBottom};

  auto drawBox = [&](const RECT& box, const wchar_t* title, const std::vector<cutting::CutItem>& items, bool bars) {
    HPEN pen = CreatePen(PS_SOLID,1,RGB(210,214,218));
    HGDIOBJ op = SelectObject(dc,pen); HGDIOBJ ob=SelectObject(dc,GetStockObject(NULL_BRUSH));
    Rectangle(dc,box.left,box.top,box.right,box.bottom);
    SelectObject(dc,ob); SelectObject(dc,op); DeleteObject(pen);
    Text(dc,box.left+14,box.top+12,title,UiTheme::Text,16,FW_BOLD);
    std::wstring count = std::to_wstring(items.size()) + L" Zuschnittgruppen";
    Text(dc,box.left+14,box.top+36,count.c_str(),UiTheme::MutedText,12);
    Text(dc,box.left+14,box.top+62,bars ? L"Anzahl   Länge × Querschnitt   Material" : L"Anzahl   Länge × Breite × Dicke   Material",UiTheme::MutedText,11,FW_SEMIBOLD);

    int y=box.top+86;
    const int maxY=box.bottom-20;
    for (const auto& item : items) {
      if (y+42 > maxY) { Text(dc,box.left+14,y,L"… weitere Gruppen",UiTheme::MutedText,11); break; }
      std::wostringstream line;
      line << item.quantity << L" ×   " << std::fixed << std::setprecision(1);
      if (bars) line << item.lengthMm << L" × " << item.widthMm << L" × " << item.thicknessMm;
      else line << item.lengthMm << L" × " << item.widthMm << L" × " << item.thicknessMm;
      line << L" mm";
      Text(dc,box.left+14,y,line.str().c_str(),UiTheme::Text,12,FW_SEMIBOLD);
      std::wstring material = item.material.empty() ? L"Nicht zugewiesen" : item.material;
      Text(dc,box.left+14,y+18,material.c_str(),UiTheme::MutedText,11);
      std::wstring ids=L"IDs: ";
      for (size_t i=0; i<item.partIds.size() && i<5; ++i) { if (i) ids += L", "; ids += item.partIds[i]; }
      if (item.partIds.size()>5) ids += L", …";
      Text(dc,box.left+14,y+32,ids.c_str(),UiTheme::MutedText,10);
      y += 54;
    }
    if (items.empty()) Text(dc,box.left+14,box.top+94,L"Keine passenden Bauteile vorhanden.",UiTheme::MutedText,12);
  };

  drawBox(sheetBox,L"PLATTENZUSCHNITT",sheetCuts_,false);
  drawBox(barBox,L"STAB- / BALKENZUSCHNITT",barCuts_,true);
}

bool MainWindow::SaveProject(bool saveAs) {
  if (!document_) return false;
  std::wstring path = projectPath_;
  if (saveAs || path.empty()) {
    wchar_t buffer[MAX_PATH] = L"Holzbauplaner_Projekt.hbp";
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd_;
    ofn.lpstrFilter = L"Holzbauplaner-Projekt (*.hbp)\0*.hbp\0Alle Dateien (*.*)\0*.*\0";
    ofn.lpstrFile = buffer;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = L"hbp";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    if (!GetSaveFileNameW(&ofn)) return false;
    path = buffer;
  }
  std::wstring error;
  if (!projectFile_.Save(path, *document_, error)) {
    uiMessage_ = L"Speichern fehlgeschlagen: " + error;
    InvalidateRect(hwnd_, nullptr, FALSE);
    return false;
  }
  projectPath_ = path;
  uiMessage_ = L"Projekt gespeichert";
  InvalidateRect(hwnd_, nullptr, FALSE);
  return true;
}

bool MainWindow::OpenProject() {
  if (!document_) return false;
  wchar_t buffer[MAX_PATH] = L"";
  OPENFILENAMEW ofn{};
  ofn.lStructSize = sizeof(ofn);
  ofn.hwndOwner = hwnd_;
  ofn.lpstrFilter = L"Holzbauplaner-Projekt (*.hbp)\0*.hbp\0Alle Dateien (*.*)\0*.*\0";
  ofn.lpstrFile = buffer;
  ofn.nMaxFile = MAX_PATH;
  ofn.lpstrDefExt = L"hbp";
  ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
  if (!GetOpenFileNameW(&ofn)) return false;

  document::DocumentState loaded;
  std::wstring error;
  if (!projectFile_.Load(buffer, loaded, error)) {
    uiMessage_ = L"Öffnen fehlgeschlagen: " + error;
    InvalidateRect(hwnd_, nullptr, FALSE);
    return false;
  }

  document_->RestoreState(loaded, true);
  projectPath_ = buffer;
  partDrawingOpen_ = false;
  cuttingOpen_ = false;
  numericInput_.clear();
  viewer_.ReloadDocument();
  uiMessage_ = L"Projekt geladen · " + std::to_wstring(document_->Parts().All().size()) + L" Bauteile";
  Layout();
  InvalidateRect(hwnd_, nullptr, TRUE);
  return true;
}

bool MainWindow::UndoProject() {
  if (!document_ || !document_->Undo()) {
    uiMessage_ = L"Nichts zum Rückgängig machen";
    InvalidateRect(hwnd_, nullptr, FALSE);
    return false;
  }
  partDrawingOpen_ = false;
  cuttingOpen_ = false;
  numericInput_.clear();
  viewer_.ReloadDocument();
  uiMessage_ = L"Rückgängig";
  Layout();
  InvalidateRect(hwnd_, nullptr, TRUE);
  return true;
}

bool MainWindow::RedoProject() {
  if (!document_ || !document_->Redo()) {
    uiMessage_ = L"Nichts zum Wiederholen";
    InvalidateRect(hwnd_, nullptr, FALSE);
    return false;
  }
  partDrawingOpen_ = false;
  cuttingOpen_ = false;
  numericInput_.clear();
  viewer_.ReloadDocument();
  uiMessage_ = L"Wiederholt";
  Layout();
  InvalidateRect(hwnd_, nullptr, TRUE);
  return true;
}

bool MainWindow::HandleToolbarClick(int x, int y) {
  if (y < 0 || y >= kTopBar) return false;
  const int firstX = 286;
  const int step = 108;
  if (x < firstX) return false;
  const int index = (x - firstX) / step;
  const int within = (x - firstX) % step;
  if (within < 0 || within >= 102 || index < 0 || index > 6) return false;

  if (index == 0) return SaveProject(false);
  if (index == 1) return OpenProject();
  if (index == 2) return UndoProject();
  if (index == 3) return RedoProject();

  if (index == 4) {
    partDrawingOpen_ = false;
    cuttingOpen_ = false;
    uiMessage_.clear();
    viewer_.ActivateSelectionTool();
    numericInput_.clear();
    viewer_.ToggleExplodedView();
    Layout();
    InvalidateRect(hwnd_, nullptr, TRUE);
    if (viewportHwnd_) SetFocus(viewportHwnd_);
    return true;
  }

  if (index == 5) {
    cuttingOpen_ = false;
    if (partDrawingOpen_) {
      partDrawingOpen_ = false;
      uiMessage_.clear();
      Layout();
      InvalidateRect(hwnd_, nullptr, TRUE);
      if (viewportHwnd_) SetFocus(viewportHwnd_);
      return true;
    }

    const auto& selection = viewer_.CurrentSelection();
    TopoDS_Shape owner = selection.ownerShape.IsNull() ? selection.shape : selection.ownerShape;
    const parts::PartRecord* part = (document_ && !owner.IsNull()) ? document_->FindPart(owner) : nullptr;
    if (!part) {
      uiMessage_ = L"Für Bauplan zuerst ein Projektbauteil auswählen";
      InvalidateRect(hwnd_, nullptr, FALSE);
      return true;
    }

    viewer_.ActivateSelectionTool();
    numericInput_.clear();
    drawingSheet_ = partDrawing_.Build(*part);
    partDrawingOpen_ = true;
    uiMessage_ = part->id + L" · " + part->name;
    Layout();
    InvalidateRect(hwnd_, nullptr, TRUE);
    return true;
  }

  if (index == 6) {
    partDrawingOpen_ = false;
    if (cuttingOpen_) {
      cuttingOpen_ = false;
      uiMessage_.clear();
      Layout();
      InvalidateRect(hwnd_, nullptr, TRUE);
      if (viewportHwnd_) SetFocus(viewportHwnd_);
      return true;
    }
    if (!document_) {
      uiMessage_ = L"Kein Projektmodell für Zuschnitt vorhanden";
      InvalidateRect(hwnd_, nullptr, FALSE);
      return true;
    }
    viewer_.ActivateSelectionTool();
    numericInput_.clear();
    sheetCuts_ = sheetCutting_.Build(document_->Parts());
    barCuts_ = barCutting_.Build(document_->Parts());
    cuttingOpen_ = true;
    uiMessage_ = L"Zuschnitt aus " + std::to_wstring(document_->Parts().All().size()) + L" Bauteilen";
    Layout();
    InvalidateRect(hwnd_, nullptr, TRUE);
    return true;
  }

  return false;
}

bool MainWindow::HandleRightPanelClick(int x, int y) {
  RECT client{}; GetClientRect(hwnd_, &client);
  const int left = client.right - kRightPanel;
  if (x < left || x >= client.right || y < kTopBar || y >= client.bottom-kStatusBar) return false;

  const int localY = y - kTopBar;
  if (localY >= 258 && localY < 294) viewer_.ToggleGrid();
  else if (localY >= 302 && localY < 338) viewer_.ToggleXRay();
  else if (localY >= 346 && localY < 382) viewer_.CycleReferenceDisplay();
  else return false;

  InvalidateRect(hwnd_, nullptr, FALSE);
  if (viewportHwnd_) SetFocus(viewportHwnd_);
  return true;
}

void MainWindow::ActivateToolFromSidebar(int x, int y) {
  if (x < 0 || x >= kLeftBar || y < kTopBar) return;
  const int firstY = kTopBar + 10;
  const int step = 57;
  const int index = (y - firstY) / step;
  const int within = (y - firstY) % step;
  if (within < 0 || within > 52) return;

  if (index == 0) {
    viewer_.ActivateSelectionTool();
    numericInput_.clear();
  } else if (index == 1) {
    viewer_.ActivateRectangleTool();
    numericInput_.clear();
  } else if (index == 2) {
    viewer_.ActivateCircleTool();
    numericInput_.clear();
  } else if (index == 3) {
    viewer_.ActivatePencilTool();
    numericInput_.clear();
  } else if (index == 4) {
    viewer_.ActivateArcTool();
    numericInput_.clear();
  } else if (index == 5) {
    viewer_.ActivatePushPullTool();
    numericInput_.clear();
  } else if (index == 6) {
    viewer_.ActivateOffsetTool();
    numericInput_.clear();
  } else if (index == 7) {
    viewer_.ActivateDeleteTool();
    numericInput_.clear();
  } else if (index == 8) {
    viewer_.ActivateChamferTool();
    numericInput_.clear();
  } else if (index == 9) {
    viewer_.ActivateFilletTool();
    numericInput_.clear();
  } else if (index == 10) {
    viewer_.ActivateConstructionLineTool();
    numericInput_.clear();
  } else if (index == 11) {
    viewer_.ActivateMeasureTool();
    numericInput_.clear();
  } else if (index == 12) {
    viewer_.ActivateAngleTool();
    numericInput_.clear();
  } else {
    return; // weitere Werkzeuge kommen in ihren eigenen Versionen
  }
  if (viewportHwnd_) SetFocus(viewportHwnd_);
  InvalidateRect(hwnd_, nullptr, FALSE);
}

void MainWindow::HandleNumericChar(wchar_t ch) {
  if (!viewer_.RectangleActive() && !viewer_.CircleActive() && !viewer_.PushPullActive() && !viewer_.OffsetActive() && !viewer_.ChamferActive() && !viewer_.FilletActive()) return;
  if (ch == L'\r') {
    if (viewer_.RectangleActive()) CommitNumericRectangle();
    else if (viewer_.CircleActive()) CommitNumericCircle();
    else if (viewer_.PushPullActive()) CommitNumericPushPull();
    else if (viewer_.OffsetActive()) CommitNumericOffset();
    else if (viewer_.ChamferActive()) CommitNumericChamfer();
    else if (viewer_.FilletActive()) CommitNumericFillet();
    return;
  }
  if (ch == L'\b') {
    if (!numericInput_.empty()) numericInput_.pop_back();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return;
  }
  if (std::iswdigit(ch) || ch == L'.' || ch == L',' || ch == L'-' || ch == L'x' || ch == L'X' || ch == L';') {
    if (numericInput_.size() < 32) numericInput_.push_back(ch);
    InvalidateRect(hwnd_, nullptr, FALSE);
  }
}

bool MainWindow::CommitNumericRectangle() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) {
    if (c == L'X' || c == L';') c = L'x';
  }
  const auto sep = value.find(L'x');
  if (sep == std::wstring::npos || sep == 0 || sep + 1 >= value.size()) return false;

  std::wstring left = value.substr(0, sep);
  std::wstring right = value.substr(sep + 1);
  // Deutsche Dezimalkommas innerhalb einer Einzelzahl akzeptieren.
  for (wchar_t& c : left) if (c == L',') c = L'.';
  for (wchar_t& c : right) if (c == L',') c = L'.';

  wchar_t* endA = nullptr;
  wchar_t* endB = nullptr;
  const double width = std::wcstod(left.c_str(), &endA);
  const double height = std::wcstod(right.c_str(), &endB);
  if (!endA || *endA != L'\0' || !endB || *endB != L'\0' || width <= 0.0 || height <= 0.0) return false;

  if (viewer_.CommitRectangleDimensions(width, height)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}


bool MainWindow::CommitNumericCircle() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) if (c == L',') c = L'.';
  wchar_t* end = nullptr;
  const double radius = std::wcstod(value.c_str(), &end);
  if (!end || *end != L'\0' || radius <= 0.0) return false;
  if (viewer_.CommitCircleRadius(radius)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}

bool MainWindow::CommitNumericPushPull() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) if (c == L',') c = L'.';
  wchar_t* end = nullptr;
  const double distance = std::wcstod(value.c_str(), &end);
  if (!end || *end != L'\0' || distance == 0.0) return false;
  if (viewer_.CommitPushPullDistance(distance)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}


bool MainWindow::CommitNumericOffset() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) if (c == L',') c = L'.';
  wchar_t* end = nullptr;
  const double distance = std::wcstod(value.c_str(), &end);
  if (!end || *end != L'\0' || distance <= 0.0) return false;
  if (viewer_.CommitOffsetDistance(distance)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}


bool MainWindow::CommitNumericChamfer() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) if (c == L',') c = L'.';
  wchar_t* end = nullptr;
  const double distance = std::wcstod(value.c_str(), &end);
  if (!end || *end != L'\0' || distance <= 0.0) return false;
  if (viewer_.CommitChamferDistance(distance)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}

bool MainWindow::CommitNumericFillet() {
  if (numericInput_.empty()) return false;
  std::wstring value = numericInput_;
  for (wchar_t& c : value) if (c == L',') c = L'.';
  wchar_t* end = nullptr;
  const double radius = std::wcstod(value.c_str(), &end);
  if (!end || *end != L'\0' || radius <= 0.0) return false;
  if (viewer_.CommitFilletRadius(radius)) {
    numericInput_.clear();
    InvalidateRect(hwnd_, nullptr, FALSE);
    return true;
  }
  return false;
}

}
