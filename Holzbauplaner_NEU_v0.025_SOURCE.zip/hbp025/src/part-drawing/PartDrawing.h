#pragma once
#include "core/IModule.h"
#include "parts/PartStore.h"
#include <string>
#include <vector>

namespace hbp::part_drawing {

enum class ViewKind { Front, Top, Right };

struct Point2D {
  double x = 0.0;
  double y = 0.0;
};

struct Segment2D {
  Point2D a;
  Point2D b;
};

struct DrawingView {
  ViewKind kind = ViewKind::Front;
  std::wstring title;
  double widthMm = 0.0;
  double heightMm = 0.0;
  std::vector<Segment2D> segments;
};

struct DrawingSheet {
  std::wstring partId;
  std::wstring partName;
  std::wstring material;
  parts::PartDimensions dimensions;
  std::vector<DrawingView> views;
};

class PartDrawing final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"part-drawing"; }
  bool Initialize() override { return true; }
  void Shutdown() noexcept override {}

  DrawingSheet Build(const parts::PartRecord& part) const;

private:
  static DrawingView BuildView(const TopoDS_Shape& shape, ViewKind kind, const parts::PartDimensions& dims);
};

} // namespace hbp::part_drawing
