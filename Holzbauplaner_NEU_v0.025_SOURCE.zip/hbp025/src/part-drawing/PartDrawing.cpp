#include "part-drawing/PartDrawing.h"

#include <BRepAdaptor_Curve.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <algorithm>
#include <cmath>

namespace hbp::part_drawing {
namespace {
Point2D Project(const gp_Pnt& p, ViewKind kind) {
  switch (kind) {
    case ViewKind::Front: return {p.X(), p.Z()};
    case ViewKind::Top:   return {p.X(), p.Y()};
    case ViewKind::Right: return {p.Y(), p.Z()};
  }
  return {};
}

std::wstring Title(ViewKind kind) {
  switch (kind) {
    case ViewKind::Front: return L"Vorderansicht";
    case ViewKind::Top: return L"Draufsicht";
    case ViewKind::Right: return L"Seitenansicht";
  }
  return L"Ansicht";
}

void ViewSize(ViewKind kind, const parts::PartDimensions& dims, double& width, double& height) {
  switch (kind) {
    case ViewKind::Front: width = dims.xMm; height = dims.zMm; break;
    case ViewKind::Top: width = dims.xMm; height = dims.yMm; break;
    case ViewKind::Right: width = dims.yMm; height = dims.zMm; break;
  }
}
}

DrawingSheet PartDrawing::Build(const parts::PartRecord& part) const {
  DrawingSheet sheet;
  sheet.partId = part.id;
  sheet.partName = part.name;
  sheet.material = part.material;
  sheet.dimensions = part.dimensions;
  if (part.shape.IsNull()) return sheet;
  sheet.views.push_back(BuildView(part.shape, ViewKind::Front, part.dimensions));
  sheet.views.push_back(BuildView(part.shape, ViewKind::Top, part.dimensions));
  sheet.views.push_back(BuildView(part.shape, ViewKind::Right, part.dimensions));
  return sheet;
}

DrawingView PartDrawing::BuildView(const TopoDS_Shape& shape, ViewKind kind, const parts::PartDimensions& dims) {
  DrawingView view;
  view.kind = kind;
  view.title = Title(kind);
  ViewSize(kind, dims, view.widthMm, view.heightMm);

  for (TopExp_Explorer exp(shape, TopAbs_EDGE); exp.More(); exp.Next()) {
    const TopoDS_Edge edge = TopoDS::Edge(exp.Current());
    BRepAdaptor_Curve curve(edge);
    const double first = curve.FirstParameter();
    const double last = curve.LastParameter();
    if (!std::isfinite(first) || !std::isfinite(last) || std::abs(last-first) < 1e-12) continue;

    constexpr int kSamples = 20;
    gp_Pnt previous;
    curve.D0(first, previous);
    for (int i = 1; i <= kSamples; ++i) {
      const double u = first + (last-first) * (static_cast<double>(i) / kSamples);
      gp_Pnt current;
      curve.D0(u, current);
      const Point2D a = Project(previous, kind);
      const Point2D b = Project(current, kind);
      const double dx = b.x-a.x;
      const double dy = b.y-a.y;
      if (dx*dx + dy*dy > 1e-10) view.segments.push_back({a,b});
      previous = current;
    }
  }
  return view;
}

} // namespace hbp::part_drawing
