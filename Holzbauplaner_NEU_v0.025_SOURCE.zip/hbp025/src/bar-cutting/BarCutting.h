#pragma once
#include "core/IModule.h"
#include "cutting/CutTypes.h"
#include "parts/PartStore.h"
#include <string>
#include <vector>

namespace hbp::bar_cutting {

class BarCutting final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"bar-cutting"; }
  bool Initialize() override { return true; }
  void Shutdown() noexcept override {}

  std::vector<cutting::CutItem> Build(const parts::PartStore& store) const;
  static bool IsBar(const parts::PartRecord& part);
};

} // namespace hbp::bar_cutting
