#include "bar-cutting/BarCutting.h"
#include <algorithm>
#include <cmath>

namespace hbp::bar_cutting {
namespace {
bool SameMm(double a, double b) { return std::abs(a-b) <= 0.05; }
}

bool BarCutting::IsBar(const parts::PartRecord& part) {
  double length=0.0, width=0.0, thickness=0.0;
  cutting::SortDescending(part.dimensions.xMm, part.dimensions.yMm, part.dimensions.zMm,
                          length, width, thickness);
  if (thickness <= 0.0 || width <= 0.0 || length <= 0.0) return false;
  // Stab/Balken/Leiste: Länge dominiert den Querschnitt deutlich.
  return length >= width * 3.0;
}

std::vector<cutting::CutItem> BarCutting::Build(const parts::PartStore& store) const {
  std::vector<cutting::CutItem> result;
  for (const auto& part : store.All()) {
    if (!IsBar(part)) continue;
    double length=0.0, width=0.0, thickness=0.0;
    cutting::SortDescending(part.dimensions.xMm, part.dimensions.yMm, part.dimensions.zMm,
                            length, width, thickness);

    auto it = std::find_if(result.begin(), result.end(), [&](const cutting::CutItem& item) {
      return item.material == part.material &&
             SameMm(item.lengthMm, length) && SameMm(item.widthMm, width) &&
             SameMm(item.thicknessMm, thickness);
    });
    if (it == result.end()) {
      cutting::CutItem item;
      item.material = part.material;
      item.lengthMm = length;
      item.widthMm = width;
      item.thicknessMm = thickness;
      item.quantity = 1;
      item.partIds.push_back(part.id);
      result.push_back(std::move(item));
    } else {
      ++it->quantity;
      it->partIds.push_back(part.id);
    }
  }
  std::sort(result.begin(), result.end(), [](const auto& a, const auto& b) {
    if (a.material != b.material) return a.material < b.material;
    if (!SameMm(a.widthMm,b.widthMm)) return a.widthMm < b.widthMm;
    if (!SameMm(a.thicknessMm,b.thicknessMm)) return a.thicknessMm < b.thicknessMm;
    return a.lengthMm > b.lengthMm;
  });
  return result;
}

} // namespace hbp::bar_cutting
