#include "measure/MeasureTool.h"
#include <cmath>
#include <sstream>
#include <iomanip>
namespace hbp::measure {
bool MeasureTool::PointOnGroundPlane(int x,int y,gp_Pnt& p) const { if(view_.IsNull())return false; Standard_Real px=0,py=0,pz=0,vx=0,vy=0,vz=0; view_->ConvertWithProj(x,y,px,py,pz,vx,vy,vz); if(std::abs(vz)<1e-12)return false; const double z=hasStart_?start_.Z():0.0,t=(z-pz)/vz; p=gp_Pnt(px+t*vx,py+t*vy,z); return true; }
bool MeasureTool::Click(int x,int y,const gp_Pnt* snap){ if(!active_)return false; gp_Pnt p; if(snap)p=*snap; else if(!PointOnGroundPlane(x,y,p))return false; if(!hasStart_){start_=p;hasStart_=true;result_.clear();return true;} const double d=start_.Distance(p); std::wostringstream s; s<<L"Abstand: "<<std::fixed<<std::setprecision(2)<<d<<L" mm"; result_=s.str(); hasStart_=false; return true; }
std::wstring MeasureTool::StatusText() const { if(!active_)return L"Messen inaktiv"; if(!result_.empty()&&!hasStart_)return L"Messen: "+result_+L"  •  neuer Startpunkt möglich"; return hasStart_?L"Messen: zweiten Punkt anklicken":L"Messen: ersten Punkt anklicken"; }
}
