#pragma once
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>
namespace hbp::measure {
class MeasureTool {
public:
  void Attach(const Handle(V3d_View)& view){view_=view;}
  void Detach() noexcept {view_.Nullify();active_=false;hasStart_=false;}
  void Activate(){active_=true;hasStart_=false;result_.clear();}
  void Deactivate(){active_=false;hasStart_=false;}
  bool IsActive() const noexcept{return active_;}
  bool Click(int x,int y,const gp_Pnt* snappedPoint=nullptr);
  void Cancel(){hasStart_=false;}
  std::wstring StatusText() const;
private:
  bool PointOnGroundPlane(int x,int y,gp_Pnt& point) const;
  Handle(V3d_View) view_; bool active_=false; bool hasStart_=false; gp_Pnt start_{}; std::wstring result_;
};
}
