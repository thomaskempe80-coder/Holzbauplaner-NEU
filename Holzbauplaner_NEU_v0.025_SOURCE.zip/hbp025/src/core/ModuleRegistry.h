#pragma once
#include "core/IModule.h"
#include <memory>
#include <vector>

namespace hbp::core {
class ModuleRegistry {
public:
  void Add(std::unique_ptr<IModule> module);
  bool InitializeAll();
  void ShutdownAll() noexcept;
private:
  std::vector<std::unique_ptr<IModule>> modules_;
};
}
