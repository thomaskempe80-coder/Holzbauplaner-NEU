#pragma once
#include <string_view>

namespace hbp::core {
class IModule {
public:
  virtual ~IModule() = default;
  virtual std::wstring_view Id() const noexcept = 0;
  virtual bool Initialize() = 0;
  virtual void Shutdown() noexcept = 0;
};
}
