#include "core/ModuleRegistry.h"
#include <algorithm>

namespace hbp::core {
void ModuleRegistry::Add(std::unique_ptr<IModule> module) {
  modules_.push_back(std::move(module));
}

bool ModuleRegistry::InitializeAll() {
  std::size_t initialized = 0;
  for (; initialized < modules_.size(); ++initialized) {
    if (!modules_[initialized]->Initialize()) {
      while (initialized > 0) {
        --initialized;
        modules_[initialized]->Shutdown();
      }
      return false;
    }
  }
  return true;
}

void ModuleRegistry::ShutdownAll() noexcept {
  for (auto it = modules_.rbegin(); it != modules_.rend(); ++it) {
    (*it)->Shutdown();
  }
}
}
