#pragma once

#include <string>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Edge.hxx>

namespace hbp::delete_tool {

class DeleteTool {
public:
  void Activate() noexcept;
  void Deactivate() noexcept;
  bool IsActive() const noexcept { return active_; }

  // Entfernt nur eine echte innere Trennkante. Randkanten eines Bauteils
  // werden nicht gelöscht. Andere Teilungskanten werden explizit geschützt.
  bool DeleteEdge(const TopoDS_Shape& sourceShape,
                  const TopoDS_Edge& selectedEdge);

  TopoDS_Shape TakeFinishedShape();
  const TopoDS_Shape& SourceShape() const noexcept { return sourceShape_; }
  const std::wstring& StatusText() const noexcept { return statusText_; }

private:
  bool active_ = false;
  TopoDS_Shape sourceShape_;
  TopoDS_Shape finishedShape_;
  std::wstring statusText_ = L"Löschen: Kante anklicken";
};

}
