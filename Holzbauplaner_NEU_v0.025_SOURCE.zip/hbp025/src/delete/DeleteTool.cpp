#include "delete/DeleteTool.h"

#include <ShapeUpgrade_UnifySameDomain.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedDataMapOfShapeListOfShape.hxx>
#include <TopTools_ListOfShape.hxx>
#include <TopoDS.hxx>

namespace {
int CountFaces(const TopoDS_Shape& shape) {
  int count = 0;
  for (TopExp_Explorer ex(shape, TopAbs_FACE); ex.More(); ex.Next()) ++count;
  return count;
}

bool ContainsSameEdge(const TopoDS_Shape& shape, const TopoDS_Edge& edge) {
  for (TopExp_Explorer ex(shape, TopAbs_EDGE); ex.More(); ex.Next()) {
    if (ex.Current().IsSame(edge)) return true;
  }
  return false;
}
}

namespace hbp::delete_tool {

void DeleteTool::Activate() noexcept {
  active_ = true;
  sourceShape_.Nullify();
  finishedShape_.Nullify();
  statusText_ = L"Löschen: innere Trennkante anklicken";
}

void DeleteTool::Deactivate() noexcept {
  active_ = false;
  sourceShape_.Nullify();
  finishedShape_.Nullify();
  statusText_ = L"Löschen: Kante anklicken";
}

bool DeleteTool::DeleteEdge(const TopoDS_Shape& sourceShape,
                            const TopoDS_Edge& selectedEdge) {
  finishedShape_.Nullify();
  sourceShape_.Nullify();

  if (!active_ || sourceShape.IsNull() || selectedEdge.IsNull()) {
    statusText_ = L"Löschen: keine gültige Kante";
    return false;
  }

  // Eine löschbare Trennkante muss genau zwei angrenzende Faces im selben
  // Projekt-Shape besitzen. Freie Außenkanten werden bewusst abgewiesen.
  TopTools_IndexedDataMapOfShapeListOfShape edgeFaces;
  TopExp::MapShapesAndAncestors(sourceShape, TopAbs_EDGE, TopAbs_FACE, edgeFaces);
  if (!edgeFaces.Contains(selectedEdge)) {
    statusText_ = L"Löschen: Kante gehört nicht zum Bauteil";
    return false;
  }

  const TopTools_ListOfShape& adjacentFaces = edgeFaces.FindFromKey(selectedEdge);
  if (adjacentFaces.Extent() != 2) {
    statusText_ = L"Löschen: nur innere Trennkanten sind löschbar";
    return false;
  }

  // Nur über die ausgewählte Kante darf ein Face-Merge stattfinden.
  // Alle anderen Kanten werden via KeepShape geschützt.
  ShapeUpgrade_UnifySameDomain unify(sourceShape,
                                     false, // Kanten nicht global vereinigen
                                     true,  // Faces gleicher Domäne vereinigen
                                     false);
  unify.SetSafeInputMode(true);

  for (TopExp_Explorer ex(sourceShape, TopAbs_EDGE); ex.More(); ex.Next()) {
    const TopoDS_Shape edge = ex.Current();
    if (!edge.IsSame(selectedEdge)) unify.KeepShape(edge);
  }

  const int facesBefore = CountFaces(sourceShape);
  unify.Build();
  const TopoDS_Shape result = unify.Shape();
  if (result.IsNull()) {
    statusText_ = L"Löschen: Topologie konnte nicht neu aufgebaut werden";
    return false;
  }

  const int facesAfter = CountFaces(result);
  if (facesAfter >= facesBefore || ContainsSameEdge(result, selectedEdge)) {
    statusText_ = L"Löschen: Kante trennt keine zusammenführbaren Faces";
    return false;
  }

  sourceShape_ = sourceShape;
  finishedShape_ = result;
  statusText_ = L"Löschen: Trennkante entfernt, Faces zusammengeführt";
  return true;
}

TopoDS_Shape DeleteTool::TakeFinishedShape() {
  TopoDS_Shape out = finishedShape_;
  finishedShape_.Nullify();
  return out;
}

}
