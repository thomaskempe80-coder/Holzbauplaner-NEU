#pragma once

#include <gp_Vec.hxx>
#include <string>

namespace hbp::inference {

enum class InferenceKind {
  None,
  Parallel,
  Perpendicular
};

struct InferenceResult {
  InferenceKind kind = InferenceKind::None;
  std::wstring label = L"Keine Richtungshilfe";
  double angleDegrees = 0.0;

  explicit operator bool() const noexcept { return kind != InferenceKind::None; }
};

class InferenceEngine {
public:
  // Zentrale Richtungspruefung fuer spaetere Werkzeuge. Rechteck, Bleistift usw.
  // duerfen diese Logik nicht duplizieren.
  InferenceResult Classify(const gp_Vec& currentDirection,
                           const gp_Vec& referenceDirection) const;

  void SetAngularToleranceDegrees(double degrees) noexcept;
  double AngularToleranceDegrees() const noexcept { return toleranceDegrees_; }

private:
  double toleranceDegrees_ = 5.0;
};

}
