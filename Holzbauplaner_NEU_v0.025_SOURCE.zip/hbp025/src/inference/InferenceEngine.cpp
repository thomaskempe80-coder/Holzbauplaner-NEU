#include "inference/InferenceEngine.h"

#include <algorithm>
#include <cmath>

namespace hbp::inference {
namespace {
constexpr double kPi = 3.14159265358979323846;

double Degrees(double radians) {
  return radians * 180.0 / kPi;
}
}

InferenceResult InferenceEngine::Classify(const gp_Vec& currentDirection,
                                          const gp_Vec& referenceDirection) const {
  InferenceResult result{};
  if (currentDirection.SquareMagnitude() <= 1.0e-18 ||
      referenceDirection.SquareMagnitude() <= 1.0e-18) {
    return result;
  }

  gp_Vec current = currentDirection.Normalized();
  gp_Vec reference = referenceDirection.Normalized();
  double dot = std::clamp(current.Dot(reference), -1.0, 1.0);
  double angle = Degrees(std::acos(dot));
  if (angle > 90.0) angle = 180.0 - angle; // Richtung +/- gilt als dieselbe Achse.

  result.angleDegrees = angle;
  if (angle <= toleranceDegrees_) {
    result.kind = InferenceKind::Parallel;
    result.label = L"Parallel";
  } else if (std::abs(angle - 90.0) <= toleranceDegrees_) {
    result.kind = InferenceKind::Perpendicular;
    result.label = L"90° / Senkrecht";
  }
  return result;
}

void InferenceEngine::SetAngularToleranceDegrees(double degrees) noexcept {
  toleranceDegrees_ = std::clamp(degrees, 0.1, 20.0);
}

}
