#include "save-load/ProjectFile.h"
#include <BinTools.hxx>
#include <fstream>
#include <sstream>
#include <cstdint>
#include <filesystem>

namespace {
constexpr char kMagic[8] = {'H','B','P','R','O','J','1','\0'};
constexpr std::uint32_t kFormatVersion = 1;

template <class T>
bool WritePod(std::ostream& out, const T& value) {
  out.write(reinterpret_cast<const char*>(&value), sizeof(T));
  return static_cast<bool>(out);
}

template <class T>
bool ReadPod(std::istream& in, T& value) {
  in.read(reinterpret_cast<char*>(&value), sizeof(T));
  return static_cast<bool>(in);
}

bool WriteWide(std::ostream& out, const std::wstring& value) {
  const std::uint32_t count = static_cast<std::uint32_t>(value.size());
  if (!WritePod(out, count)) return false;
  if (count) out.write(reinterpret_cast<const char*>(value.data()), count * sizeof(wchar_t));
  return static_cast<bool>(out);
}

bool ReadWide(std::istream& in, std::wstring& value) {
  std::uint32_t count = 0;
  if (!ReadPod(in, count) || count > 1'000'000) return false;
  value.assign(count, L'\0');
  if (count) in.read(reinterpret_cast<char*>(value.data()), count * sizeof(wchar_t));
  return static_cast<bool>(in);
}
}

namespace hbp::save_load {
bool ProjectFile::Save(const std::wstring& path, const document::DocumentModel& document, std::wstring& error) const {
  error.clear();
  std::ofstream out(std::filesystem::path(path), std::ios::binary | std::ios::trunc);
  if (!out) { error = L"Projektdatei konnte nicht geöffnet werden."; return false; }

  out.write(kMagic, sizeof(kMagic));
  if (!WritePod(out, kFormatVersion)) { error = L"Projektkopf konnte nicht geschrieben werden."; return false; }

  const auto state = document.CaptureState();
  if (!WriteWide(out, state.projectName)) { error = L"Projektname konnte nicht geschrieben werden."; return false; }
  if (!WritePod(out, state.parts.nextId)) { error = L"Bauteilzähler konnte nicht geschrieben werden."; return false; }
  const std::uint32_t count = static_cast<std::uint32_t>(state.parts.parts.size());
  if (!WritePod(out, count)) return false;

  for (const auto& part : state.parts.parts) {
    if (!WritePod(out, part.numericId) || !WriteWide(out, part.id) || !WriteWide(out, part.name) ||
        !WriteWide(out, part.type) || !WriteWide(out, part.material)) {
      error = L"Bauteil-Metadaten konnten nicht geschrieben werden."; return false;
    }

    std::ostringstream shapeStream(std::ios::out | std::ios::binary);
    BinTools::Write(part.shape, shapeStream);
    const std::string bytes = shapeStream.str();
    const std::uint64_t size = static_cast<std::uint64_t>(bytes.size());
    if (!WritePod(out, size)) return false;
    if (size) out.write(bytes.data(), static_cast<std::streamsize>(size));
    if (!out) { error = L"OCCT-Geometrie konnte nicht geschrieben werden."; return false; }
  }
  return true;
}

bool ProjectFile::Load(const std::wstring& path, document::DocumentState& state, std::wstring& error) const {
  error.clear();
  std::ifstream in(std::filesystem::path(path), std::ios::binary);
  if (!in) { error = L"Projektdatei konnte nicht geöffnet werden."; return false; }

  char magic[8]{};
  in.read(magic, sizeof(magic));
  if (!in || std::string(magic, magic + 7) != std::string(kMagic, kMagic + 7)) {
    error = L"Keine gültige Holzbauplaner-Projektdatei."; return false;
  }
  std::uint32_t version = 0;
  if (!ReadPod(in, version) || version != kFormatVersion) {
    error = L"Projektformat wird von dieser Version nicht unterstützt."; return false;
  }

  document::DocumentState loaded;
  if (!ReadWide(in, loaded.projectName) || !ReadPod(in, loaded.parts.nextId)) {
    error = L"Projektkopf ist beschädigt."; return false;
  }
  std::uint32_t count = 0;
  if (!ReadPod(in, count) || count > 100000) { error = L"Ungültige Bauteilanzahl."; return false; }
  loaded.parts.parts.reserve(count);

  for (std::uint32_t i = 0; i < count; ++i) {
    parts::PartRecord part;
    if (!ReadPod(in, part.numericId) || !ReadWide(in, part.id) || !ReadWide(in, part.name) ||
        !ReadWide(in, part.type) || !ReadWide(in, part.material)) {
      error = L"Bauteil-Metadaten sind beschädigt."; return false;
    }
    std::uint64_t size = 0;
    if (!ReadPod(in, size) || size > 512ull * 1024ull * 1024ull) { error = L"Ungültige Geometriegröße."; return false; }
    std::string bytes(static_cast<std::size_t>(size), '\0');
    if (size) in.read(bytes.data(), static_cast<std::streamsize>(size));
    if (!in) { error = L"Geometriedaten sind unvollständig."; return false; }

    std::istringstream shapeStream(bytes, std::ios::in | std::ios::binary);
    BinTools::Read(part.shape, shapeStream);
    if (!shapeStream || part.shape.IsNull()) {
      error = L"OCCT-Geometrie konnte nicht gelesen werden."; return false;
    }
    loaded.parts.parts.push_back(std::move(part));
  }

  state = std::move(loaded);
  return true;
}
}
