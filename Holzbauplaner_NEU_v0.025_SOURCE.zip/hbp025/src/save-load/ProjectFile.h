#pragma once
#include "core/IModule.h"
#include "document-model/DocumentModel.h"
#include <string>

namespace hbp::save_load {
class ProjectFile final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"save-load"; }
  bool Initialize() override { return true; }
  void Shutdown() noexcept override {}

  bool Save(const std::wstring& path, const document::DocumentModel& document, std::wstring& error) const;
  bool Load(const std::wstring& path, document::DocumentState& state, std::wstring& error) const;
};
}
