#pragma once
#include "core/IModule.h"
#include "parts/PartStore.h"
#include <TopoDS_Shape.hxx>
#include <gp_Vec.hxx>
#include <vector>

namespace hbp::exploded_view {

struct ExplodedPartTransform {
  TopoDS_Shape shape;
  gp_Vec translation;
};

class ExplodedView final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"exploded-view"; }
  bool Initialize() override { return true; }
  void Shutdown() noexcept override {}

  std::vector<ExplodedPartTransform> Build(const parts::PartStore& parts) const;
};

} // namespace hbp::exploded_view
