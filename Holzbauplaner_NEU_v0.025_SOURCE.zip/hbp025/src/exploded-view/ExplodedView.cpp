#include "exploded-view/ExplodedView.h"

#include <Bnd_Box.hxx>
#include <BRepBndLib.hxx>
#include <gp_Pnt.hxx>
#include <algorithm>
#include <cmath>

namespace hbp::exploded_view {
namespace {

struct BoundsData {
  gp_Pnt center;
  double diagonal = 0.0;
  bool valid = false;
};

BoundsData BoundsOf(const TopoDS_Shape& shape) {
  BoundsData out;
  if (shape.IsNull()) return out;

  Bnd_Box box;
  BRepBndLib::Add(shape, box);
  if (box.IsVoid()) return out;

  Standard_Real xmin=0.0, ymin=0.0, zmin=0.0;
  Standard_Real xmax=0.0, ymax=0.0, zmax=0.0;
  box.Get(xmin, ymin, zmin, xmax, ymax, zmax);
  out.center = gp_Pnt((xmin+xmax)*0.5, (ymin+ymax)*0.5, (zmin+zmax)*0.5);
  const double dx = xmax-xmin;
  const double dy = ymax-ymin;
  const double dz = zmax-zmin;
  out.diagonal = std::sqrt(dx*dx + dy*dy + dz*dz);
  out.valid = true;
  return out;
}

} // namespace

std::vector<ExplodedPartTransform> ExplodedView::Build(const parts::PartStore& store) const {
  const auto& records = store.All();
  std::vector<ExplodedPartTransform> result;
  result.reserve(records.size());
  if (records.empty()) return result;

  Bnd_Box assemblyBox;
  for (const auto& part : records) {
    if (!part.shape.IsNull()) BRepBndLib::Add(part.shape, assemblyBox);
  }
  if (assemblyBox.IsVoid()) return result;

  Standard_Real xmin=0.0, ymin=0.0, zmin=0.0;
  Standard_Real xmax=0.0, ymax=0.0, zmax=0.0;
  assemblyBox.Get(xmin, ymin, zmin, xmax, ymax, zmax);
  const gp_Pnt assemblyCenter((xmin+xmax)*0.5, (ymin+ymax)*0.5, (zmin+zmax)*0.5);
  const double adx=xmax-xmin, ady=ymax-ymin, adz=zmax-zmin;
  const double assemblyDiagonal = std::sqrt(adx*adx + ady*ady + adz*adz);
  const double baseGap = std::max(120.0, assemblyDiagonal * 0.16);

  for (std::size_t i=0; i<records.size(); ++i) {
    const auto& part = records[i];
    if (part.shape.IsNull()) continue;
    const BoundsData bounds = BoundsOf(part.shape);
    if (!bounds.valid) continue;

    gp_Vec direction(assemblyCenter, bounds.center);
    if (direction.SquareMagnitude() < 1.0e-8) {
      // Deterministic fallback for a part sitting exactly at the assembly center.
      switch (i % 6) {
        case 0: direction = gp_Vec(1,0,0); break;
        case 1: direction = gp_Vec(-1,0,0); break;
        case 2: direction = gp_Vec(0,1,0); break;
        case 3: direction = gp_Vec(0,-1,0); break;
        case 4: direction = gp_Vec(0,0,1); break;
        default: direction = gp_Vec(0,0,-1); break;
      }
    }
    direction.Normalize();

    // Add a small part-size term so large members separate more clearly.
    const double distance = baseGap + std::min(bounds.diagonal * 0.20, baseGap * 1.5);
    result.push_back({part.shape, direction * distance});
  }

  return result;
}

} // namespace hbp::exploded_view
