#include "pencil/PencilTool.h"

#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakePolygon.hxx>
#include <BRepFeat_SplitShape.hxx>
#include <BRep_Tool.hxx>
#include <IntCurvesFace_ShapeIntersector.hxx>
#include <Quantity_Color.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Wire.hxx>
#include <gp_Dir.hxx>
#include <gp_Lin.hxx>
#include <gp_Vec.hxx>
#include <Geom_Curve.hxx>
#include <limits>

namespace hbp::pencil {
namespace {
constexpr double kTolerance = 1.0e-6;
}

void PencilTool::Attach(const Handle(AIS_InteractiveContext)& context,
                        const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
}

void PencilTool::Detach() noexcept {
  Deactivate();
  finished_.Nullify();
  sourceShape_.Nullify();
  workingShape_.Nullify();
  replacementSource_.Nullify();
  activeFace_.Nullify();
  view_.Nullify();
  context_.Nullify();
}

bool PencilTool::Activate(const TopoDS_Face& face, const TopoDS_Shape& ownerShape) {
  if (face.IsNull()) return false;
  Cancel();
  active_ = true;
  activeFace_ = face;
  sourceShape_ = ownerShape.IsNull() ? TopoDS_Shape(face) : ownerShape;
  workingShape_ = sourceShape_;
  replacementSource_ = sourceShape_;
  return true;
}

void PencilTool::Deactivate() {
  Cancel();
  active_ = false;
  activeFace_.Nullify();
  sourceShape_.Nullify();
  workingShape_.Nullify();
  replacementSource_.Nullify();
}

bool PencilTool::ProjectToFace(int x, int y, const TopoDS_Face& face, gp_Pnt& point) const {
  if (view_.IsNull() || face.IsNull()) return false;
  Standard_Real px=0.0, py=0.0, pz=0.0, vx=0.0, vy=0.0, vz=0.0;
  view_->ConvertWithProj(x, y, px, py, pz, vx, vy, vz);
  const gp_Vec direction(vx, vy, vz);
  if (direction.SquareMagnitude() < 1.0e-20) return false;

  IntCurvesFace_ShapeIntersector hit;
  hit.Load(face, 1.0e-7);
  hit.Perform(gp_Lin(gp_Pnt(px,py,pz), gp_Dir(direction)), -1.0e9, 1.0e9);
  if (!hit.IsDone() || hit.NbPnt() < 1) return false;

  double best = std::numeric_limits<double>::max();
  int bestIndex = 0;
  for (int i=1; i<=hit.NbPnt(); ++i) {
    const double w = hit.WParameter(i);
    const double score = w >= 0.0 ? w : (1.0e8 + -w);
    if (score < best) { best = score; bestIndex = i; }
  }
  if (bestIndex == 0) return false;
  point = hit.Pnt(bestIndex);
  return true;
}

bool PencilTool::PickFaceAndPoint(int x, int y, TopoDS_Face& face, gp_Pnt& point) const {
  if (workingShape_.IsNull()) return false;
  double bestDistance = std::numeric_limits<double>::max();
  bool found = false;

  Standard_Real px=0.0, py=0.0, pz=0.0, vx=0.0, vy=0.0, vz=0.0;
  view_->ConvertWithProj(x, y, px, py, pz, vx, vy, vz);
  const gp_Vec direction(vx,vy,vz);
  if (direction.SquareMagnitude() < 1.0e-20) return false;
  const gp_Lin ray(gp_Pnt(px,py,pz), gp_Dir(direction));

  for (TopExp_Explorer ex(workingShape_, TopAbs_FACE); ex.More(); ex.Next()) {
    const TopoDS_Face candidate = TopoDS::Face(ex.Current());
    IntCurvesFace_ShapeIntersector hit;
    hit.Load(candidate, 1.0e-7);
    hit.Perform(ray, 0.0, 1.0e9);
    if (!hit.IsDone()) continue;
    for (int i=1; i<=hit.NbPnt(); ++i) {
      const double w = hit.WParameter(i);
      if (w >= 0.0 && w < bestDistance) {
        bestDistance = w;
        point = hit.Pnt(i);
        face = candidate;
        found = true;
      }
    }
  }
  return found;
}

bool PencilTool::IsNear(const gp_Pnt& a, const gp_Pnt& b, double toleranceMm) const {
  return a.Distance(b) <= toleranceMm;
}

bool PencilTool::IsOnBoundary(const TopoDS_Face& face, const gp_Pnt& point, double toleranceMm) const {
  for (TopExp_Explorer ex(face, TopAbs_EDGE); ex.More(); ex.Next()) {
    const TopoDS_Edge edge = TopoDS::Edge(ex.Current());
    Standard_Real first=0.0, last=0.0;
    const Handle(Geom_Curve) curve = BRep_Tool::Curve(edge, first, last);
    if (curve.IsNull()) continue;
    constexpr int samples = 32;
    for (int i=0; i<=samples; ++i) {
      const double t = first + (last-first) * (static_cast<double>(i)/samples);
      if (curve->Value(t).Distance(point) <= toleranceMm) return true;
    }
  }
  return false;
}

bool PencilTool::Click(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_) return false;

  gp_Pnt point;
  TopoDS_Face hitFace;
  if (!hasStart_) {
    if (!PickFaceAndPoint(x, y, hitFace, point)) return false;
    if (snappedPoint) point = *snappedPoint;
    activeFace_ = hitFace;
    start_ = point;
    hasStart_ = true;
    if (!IsOnBoundary(activeFace_, point)) {
      collectingClosedContour_ = true;
      contourPoints_.clear();
      contourPoints_.push_back(point);
      firstContourPoint_ = point;
    }
    return true;
  }

  if (snappedPoint) point = *snappedPoint;
  else if (!ProjectToFace(x, y, activeFace_, point)) return false;
  return FinishSegment(point);
}

void PencilTool::Move(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_ || !hasStart_) return;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!ProjectToFace(x, y, activeFace_, point)) return;
  UpdatePreview(point);
}

bool PencilTool::FinishSegment(const gp_Pnt& endPoint) {
  if (start_.Distance(endPoint) <= kTolerance) return false;

  if (collectingClosedContour_) {
    contourPoints_.push_back(endPoint);
    if (contourPoints_.size() >= 4 && IsNear(endPoint, firstContourPoint_)) {
      contourPoints_.back() = firstContourPoint_;
      if (!SplitWithClosedWire()) return false;
      ClearContourGuides();
      collectingClosedContour_ = false;
      contourPoints_.clear();
      hasStart_ = false;
      RemovePreview();
      return true;
    }
    AddContourGuide(start_, endPoint);
    start_ = endPoint;
    RemovePreview();
    return true;
  }

  if (!SplitWithSegment(start_, endPoint)) return false;
  hasStart_ = false;
  RemovePreview();
  return true;
}

bool PencilTool::SplitWithSegment(const gp_Pnt& a, const gp_Pnt& b) {
  BRepBuilderAPI_MakeEdge edgeMaker(a,b);
  if (!edgeMaker.IsDone()) return false;
  const TopoDS_Edge edge = edgeMaker.Edge();

  replacementSource_ = workingShape_;
  BRepFeat_SplitShape splitter(workingShape_);
  splitter.Add(edge, activeFace_);
  splitter.Build();
  if (!splitter.IsDone()) return false;
  const TopoDS_Shape result = splitter.Shape();
  if (result.IsNull()) return false;
  workingShape_ = result;
  finished_ = result;
  activeFace_.Nullify();
  return true;
}

bool PencilTool::SplitWithClosedWire() {
  if (contourPoints_.size() < 4 || activeFace_.IsNull()) return false;
  BRepBuilderAPI_MakePolygon polygon;
  for (size_t i=0; i+1<contourPoints_.size(); ++i) polygon.Add(contourPoints_[i]);
  polygon.Close();
  if (!polygon.IsDone()) return false;
  const TopoDS_Wire wire = polygon.Wire();

  replacementSource_ = workingShape_;
  BRepFeat_SplitShape splitter(workingShape_);
  splitter.Add(wire, activeFace_);
  splitter.Build();
  if (!splitter.IsDone()) return false;
  const TopoDS_Shape result = splitter.Shape();
  if (result.IsNull()) return false;
  workingShape_ = result;
  finished_ = result;
  activeFace_.Nullify();
  return true;
}

void PencilTool::UpdatePreview(const gp_Pnt& point) {
  BRepBuilderAPI_MakeEdge edgeMaker(start_, point);
  if (!edgeMaker.IsDone()) return;
  Handle(AIS_Shape) ais = new AIS_Shape(edgeMaker.Edge());
  ais->SetColor(Quantity_Color(0.16, 0.39, 0.72, Quantity_TOC_RGB));
  ais->SetWidth(2.5);
  RemovePreview();
  preview_ = ais;
  if (!context_.IsNull()) {
    context_->Display(preview_, Standard_False);
    context_->Deactivate(preview_);
    context_->UpdateCurrentViewer();
  }
}

void PencilTool::RemovePreview() {
  if (!context_.IsNull() && !preview_.IsNull()) {
    context_->Remove(preview_, Standard_False);
    context_->UpdateCurrentViewer();
  }
  preview_.Nullify();
}

void PencilTool::AddContourGuide(const gp_Pnt& a, const gp_Pnt& b) {
  BRepBuilderAPI_MakeEdge edgeMaker(a,b);
  if (!edgeMaker.IsDone() || context_.IsNull()) return;
  Handle(AIS_Shape) ais = new AIS_Shape(edgeMaker.Edge());
  ais->SetColor(Quantity_Color(0.16, 0.39, 0.72, Quantity_TOC_RGB));
  ais->SetWidth(2.0);
  context_->Display(ais, Standard_False);
  context_->Deactivate(ais);
  contourGuides_.push_back(ais);
  context_->UpdateCurrentViewer();
}

void PencilTool::ClearContourGuides() {
  if (!context_.IsNull()) {
    for (const auto& ais : contourGuides_) {
      if (!ais.IsNull()) context_->Remove(ais, Standard_False);
    }
    if (!contourGuides_.empty()) context_->UpdateCurrentViewer();
  }
  contourGuides_.clear();
}

void PencilTool::Cancel() {
  hasStart_ = false;
  collectingClosedContour_ = false;
  contourPoints_.clear();
  ClearContourGuides();
  RemovePreview();
}

TopoDS_Shape PencilTool::TakeFinishedShape() {
  TopoDS_Shape out = finished_;
  finished_.Nullify();
  return out;
}

std::wstring PencilTool::StatusText() const {
  if (!active_) return L"Bleistift inaktiv";
  if (!hasStart_) return L"Bleistift: Punkt auf einer Modellfläche anklicken";
  if (collectingClosedContour_) return L"Bleistift: Kontur weiterzeichnen; zum Startpunkt zurück zum Schließen";
  return L"Bleistift: Endpunkt der Trennlinie anklicken";
}

}
