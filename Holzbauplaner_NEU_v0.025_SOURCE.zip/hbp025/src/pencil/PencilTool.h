#pragma once

#include <AIS_InteractiveContext.hxx>
#include <AIS_Shape.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Shape.hxx>
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>
#include <vector>

namespace hbp::pencil {

class PencilTool {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context,
              const Handle(V3d_View)& view);
  void Detach() noexcept;

  bool Activate(const TopoDS_Face& face, const TopoDS_Shape& ownerShape);
  void Deactivate();
  void Cancel();
  bool IsActive() const noexcept { return active_; }

  bool Click(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Move(int x, int y, const gp_Pnt* snappedPoint = nullptr);

  bool HasFinishedShape() const noexcept { return !finished_.IsNull(); }
  TopoDS_Shape SourceShape() const { return replacementSource_; }
  TopoDS_Shape TakeFinishedShape();
  std::wstring StatusText() const;

private:
  bool PickFaceAndPoint(int x, int y, TopoDS_Face& face, gp_Pnt& point) const;
  bool ProjectToFace(int x, int y, const TopoDS_Face& face, gp_Pnt& point) const;
  bool FinishSegment(const gp_Pnt& endPoint);
  bool SplitWithSegment(const gp_Pnt& a, const gp_Pnt& b);
  bool SplitWithClosedWire();
  bool IsNear(const gp_Pnt& a, const gp_Pnt& b, double toleranceMm = 2.0) const;
  bool IsOnBoundary(const TopoDS_Face& face, const gp_Pnt& point, double toleranceMm = 0.5) const;
  void UpdatePreview(const gp_Pnt& point);
  void RemovePreview();
  void AddContourGuide(const gp_Pnt& a, const gp_Pnt& b);
  void ClearContourGuides();

  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  Handle(AIS_Shape) preview_;
  std::vector<Handle(AIS_Shape)> contourGuides_;
  TopoDS_Shape sourceShape_;
  TopoDS_Shape workingShape_;
  TopoDS_Shape replacementSource_;
  TopoDS_Shape finished_;
  TopoDS_Face activeFace_;
  bool active_ = false;
  bool hasStart_ = false;
  bool collectingClosedContour_ = false;
  gp_Pnt start_{};
  gp_Pnt firstContourPoint_{};
  std::vector<gp_Pnt> contourPoints_;
};

}
