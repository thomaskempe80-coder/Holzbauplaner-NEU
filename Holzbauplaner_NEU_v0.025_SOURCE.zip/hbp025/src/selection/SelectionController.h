#pragma once

#include <AIS_InteractiveContext.hxx>
#include <V3d_View.hxx>
#include <string>
#include <TopoDS_Shape.hxx>

namespace hbp::selection {

enum class SelectionKind {
  None,
  Body,
  Face,
  Edge,
  Vertex,
  Other
};

struct SelectionInfo {
  SelectionKind kind = SelectionKind::None;
  std::wstring label = L"Kein Bauteil ausgewählt";
  TopoDS_Shape shape;
  TopoDS_Shape ownerShape;
};

class SelectionController {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context,
              const Handle(V3d_View)& view);
  void Detach() noexcept;

  void ConfigureSelectableObject(const Handle(AIS_InteractiveObject)& object);
  void HoverAt(int x, int y);
  bool SelectAt(int x, int y);
  void ClearSelection();

  const SelectionInfo& Current() const noexcept { return current_; }

private:
  void UpdateInfoFromContext();

  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  SelectionInfo current_{};
};

}
