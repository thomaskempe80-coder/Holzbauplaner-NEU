#include "selection/SelectionController.h"

#include <AIS_Shape.hxx>
#include <AIS_SelectionScheme.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopoDS_Shape.hxx>

namespace hbp::selection {

void SelectionController::Attach(const Handle(AIS_InteractiveContext)& context,
                                 const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
  current_ = {};
}

void SelectionController::Detach() noexcept {
  current_ = {};
  view_.Nullify();
  context_.Nullify();
}

void SelectionController::ConfigureSelectableObject(const Handle(AIS_InteractiveObject)& object) {
  if (context_.IsNull() || object.IsNull()) return;

  // Ein zentraler Auswahlweg fuer das ganze Programm: kompletter Koerper sowie
  // echte OCCT-Unterformen. Werkzeuge bauen spaeter keine eigene Pick-Logik.
  context_->Activate(object, 0, Standard_True); // gesamtes AIS-Objekt / Body
  context_->Activate(object, AIS_Shape::SelectionMode(TopAbs_FACE), Standard_True);
  context_->Activate(object, AIS_Shape::SelectionMode(TopAbs_EDGE), Standard_True);
  context_->Activate(object, AIS_Shape::SelectionMode(TopAbs_VERTEX), Standard_True);
}

void SelectionController::HoverAt(int x, int y) {
  if (context_.IsNull() || view_.IsNull()) return;
  context_->MoveTo(x, y, view_, Standard_True);
}

bool SelectionController::SelectAt(int x, int y) {
  if (context_.IsNull() || view_.IsNull()) return false;

  context_->MoveTo(x, y, view_, Standard_False);
  if (!context_->HasDetected()) {
    ClearSelection();
    return false;
  }

  context_->SelectDetected(AIS_SelectionScheme_Replace);
  UpdateInfoFromContext();
  context_->UpdateCurrentViewer();
  return current_.kind != SelectionKind::None;
}

void SelectionController::ClearSelection() {
  if (!context_.IsNull()) {
    context_->ClearSelected(Standard_True);
  }
  current_ = {};
}

void SelectionController::UpdateInfoFromContext() {
  current_ = {};
  if (context_.IsNull() || !context_->HasSelectedShape()) return;

  const TopoDS_Shape shape = context_->SelectedShape();
  if (shape.IsNull()) return;
  current_.shape = shape;
  Handle(AIS_InteractiveObject) selected = context_->SelectedInteractive();
  Handle(AIS_Shape) owner = Handle(AIS_Shape)::DownCast(selected);
  if (!owner.IsNull()) current_.ownerShape = owner->Shape();

  switch (shape.ShapeType()) {
    case TopAbs_SOLID:
    case TopAbs_COMPSOLID:
    case TopAbs_SHELL:
    case TopAbs_COMPOUND:
      current_.kind = SelectionKind::Body;
      current_.label = L"Bauteil / Körper ausgewählt";
      break;
    case TopAbs_FACE:
      current_.kind = SelectionKind::Face;
      current_.label = L"Fläche ausgewählt";
      break;
    case TopAbs_EDGE:
      current_.kind = SelectionKind::Edge;
      current_.label = L"Kante ausgewählt";
      break;
    case TopAbs_VERTEX:
      current_.kind = SelectionKind::Vertex;
      current_.label = L"Punkt / Vertex ausgewählt";
      break;
    default:
      current_.kind = SelectionKind::Other;
      current_.label = L"Geometrie ausgewählt";
      break;
  }
}

}
