#include "sheet-cutting/SheetCutting.h"
#include <algorithm>
#include <cmath>

namespace hbp::sheet_cutting {
namespace {
bool SameMm(double a, double b) { return std::abs(a-b) <= 0.05; }
}

bool SheetCutting::IsSheet(const parts::PartRecord& part) {
  double length=0.0, width=0.0, thickness=0.0;
  cutting::SortDescending(part.dimensions.xMm, part.dimensions.yMm, part.dimensions.zMm,
                          length, width, thickness);
  if (thickness <= 0.0 || width <= 0.0 || length <= 0.0) return false;

  // Platten/Bretter: zwei ausgeprägte Flächendimensionen, relativ geringe Dicke.
  // Lange Balken/Leisten werden dem Stabzuschnitt überlassen.
  const bool longBar = length >= width * 3.0;
  const bool thinPlate = thickness <= 80.0 && width >= thickness * 2.0;
  return thinPlate && !longBar;
}

std::vector<cutting::CutItem> SheetCutting::Build(const parts::PartStore& store) const {
  std::vector<cutting::CutItem> result;
  for (const auto& part : store.All()) {
    if (!IsSheet(part)) continue;
    double length=0.0, width=0.0, thickness=0.0;
    cutting::SortDescending(part.dimensions.xMm, part.dimensions.yMm, part.dimensions.zMm,
                            length, width, thickness);

    auto it = std::find_if(result.begin(), result.end(), [&](const cutting::CutItem& item) {
      return item.material == part.material &&
             SameMm(item.lengthMm, length) && SameMm(item.widthMm, width) &&
             SameMm(item.thicknessMm, thickness);
    });
    if (it == result.end()) {
      cutting::CutItem item;
      item.material = part.material;
      item.lengthMm = length;
      item.widthMm = width;
      item.thicknessMm = thickness;
      item.quantity = 1;
      item.partIds.push_back(part.id);
      result.push_back(std::move(item));
    } else {
      ++it->quantity;
      it->partIds.push_back(part.id);
    }
  }
  std::sort(result.begin(), result.end(), [](const auto& a, const auto& b) {
    if (a.material != b.material) return a.material < b.material;
    if (!SameMm(a.thicknessMm,b.thicknessMm)) return a.thicknessMm < b.thicknessMm;
    if (!SameMm(a.lengthMm,b.lengthMm)) return a.lengthMm > b.lengthMm;
    return a.widthMm > b.widthMm;
  });
  return result;
}

} // namespace hbp::sheet_cutting
