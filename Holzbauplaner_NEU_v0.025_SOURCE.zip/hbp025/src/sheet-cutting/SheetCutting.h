#pragma once
#include "core/IModule.h"
#include "cutting/CutTypes.h"
#include "parts/PartStore.h"
#include <string>
#include <vector>

namespace hbp::sheet_cutting {

class SheetCutting final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"sheet-cutting"; }
  bool Initialize() override { return true; }
  void Shutdown() noexcept override {}

  std::vector<cutting::CutItem> Build(const parts::PartStore& store) const;
  static bool IsSheet(const parts::PartRecord& part);
};

} // namespace hbp::sheet_cutting
