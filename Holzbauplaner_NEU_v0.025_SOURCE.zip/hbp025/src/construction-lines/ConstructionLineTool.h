#pragma once
#include <AIS_InteractiveContext.hxx>
#include <AIS_Shape.hxx>
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>
#include <vector>

namespace hbp::construction_lines {
class ConstructionLineTool {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context, const Handle(V3d_View)& view);
  void Detach() noexcept;
  void Activate();
  void Deactivate();
  bool IsActive() const noexcept { return active_; }
  bool Click(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Move(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Cancel();
  std::wstring StatusText() const;
private:
  bool PointOnGroundPlane(int x, int y, gp_Pnt& point) const;
  void UpdatePreview(const gp_Pnt& point);
  void RemovePreview();
  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  Handle(AIS_Shape) preview_;
  std::vector<Handle(AIS_Shape)> lines_;
  bool active_ = false;
  bool hasStart_ = false;
  gp_Pnt start_{};
};
}
