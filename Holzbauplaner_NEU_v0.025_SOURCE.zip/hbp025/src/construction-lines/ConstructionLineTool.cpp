#include "construction-lines/ConstructionLineTool.h"
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <Quantity_Color.hxx>
#include <cmath>

namespace hbp::construction_lines {
void ConstructionLineTool::Attach(const Handle(AIS_InteractiveContext)& context, const Handle(V3d_View)& view) { context_=context; view_=view; }
void ConstructionLineTool::Detach() noexcept {
  Cancel();
  if (!context_.IsNull()) for (auto& line: lines_) if (!line.IsNull()) context_->Remove(line, Standard_False);
  lines_.clear(); view_.Nullify(); context_.Nullify(); active_=false;
}
void ConstructionLineTool::Activate(){ active_=true; hasStart_=false; RemovePreview(); }
void ConstructionLineTool::Deactivate(){ Cancel(); active_=false; }
bool ConstructionLineTool::PointOnGroundPlane(int x,int y,gp_Pnt& point) const {
  if(view_.IsNull()) return false; Standard_Real px=0,py=0,pz=0,vx=0,vy=0,vz=0;
  view_->ConvertWithProj(x,y,px,py,pz,vx,vy,vz); if(std::abs(vz)<1e-12) return false;
  const double planeZ=hasStart_?start_.Z():0.0; const double t=(planeZ-pz)/vz;
  point=gp_Pnt(px+t*vx,py+t*vy,planeZ); return true;
}
bool ConstructionLineTool::Click(int x,int y,const gp_Pnt* snappedPoint){
  if(!active_) return false; gp_Pnt p; if(snappedPoint) p=*snappedPoint; else if(!PointOnGroundPlane(x,y,p)) return false;
  if(!hasStart_){start_=p;hasStart_=true;return true;} p.SetZ(start_.Z()); if(start_.Distance(p)<0.01) return false;
  TopoDS_Edge e=BRepBuilderAPI_MakeEdge(start_,p); Handle(AIS_Shape) ais=new AIS_Shape(e);
  ais->SetColor(Quantity_Color(0.32,0.56,0.82,Quantity_TOC_RGB)); ais->SetWidth(1.0); ais->SetDisplayMode(AIS_WireFrame);
  if(!context_.IsNull()){context_->Display(ais,Standard_False);context_->UpdateCurrentViewer();}
  lines_.push_back(ais); hasStart_=false; RemovePreview(); return true;
}
void ConstructionLineTool::Move(int x,int y,const gp_Pnt* snappedPoint){
  if(!active_||!hasStart_) return; gp_Pnt p; if(snappedPoint)p=*snappedPoint; else if(!PointOnGroundPlane(x,y,p))return; p.SetZ(start_.Z()); UpdatePreview(p);
}
void ConstructionLineTool::UpdatePreview(const gp_Pnt& p){
  RemovePreview(); if(start_.Distance(p)<0.01||context_.IsNull()) return; TopoDS_Edge e=BRepBuilderAPI_MakeEdge(start_,p); preview_=new AIS_Shape(e);
  preview_->SetColor(Quantity_Color(0.55,0.70,0.90,Quantity_TOC_RGB)); preview_->SetWidth(1.0); context_->Display(preview_,Standard_False); context_->Deactivate(preview_); context_->UpdateCurrentViewer();
}
void ConstructionLineTool::RemovePreview(){ if(!context_.IsNull()&&!preview_.IsNull()){context_->Remove(preview_,Standard_False);context_->UpdateCurrentViewer();} preview_.Nullify(); }
void ConstructionLineTool::Cancel(){hasStart_=false;RemovePreview();}
std::wstring ConstructionLineTool::StatusText() const { if(!active_) return L"Hilfslinie inaktiv"; return hasStart_?L"Hilfslinie: Endpunkt anklicken":L"Hilfslinie: Startpunkt anklicken"; }
}
