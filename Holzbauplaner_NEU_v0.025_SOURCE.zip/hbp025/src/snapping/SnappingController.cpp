#include "snapping/SnappingController.h"

#include <AIS_Point.hxx>
#include <AIS_Shape.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRep_Tool.hxx>
#include <Geom_CartesianPoint.hxx>
#include <Quantity_Color.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <algorithm>
#include <cmath>
#include <limits>

namespace hbp::snapping {
namespace {

double DistancePixels(int ax, int ay, int bx, int by) {
  const double dx = static_cast<double>(ax - bx);
  const double dy = static_cast<double>(ay - by);
  return std::sqrt(dx * dx + dy * dy);
}

void AcceptCandidate(SnapResult& best,
                     SnapKind kind,
                     const gp_Pnt& point,
                     int sx,
                     int sy,
                     double distance,
                     const wchar_t* label) {
  if (best.kind != SnapKind::None && distance >= best.distancePixels) return;
  best.kind = kind;
  best.point = point;
  best.screenX = sx;
  best.screenY = sy;
  best.distancePixels = distance;
  best.label = label;
}

}

void SnappingController::Attach(const Handle(AIS_InteractiveContext)& context,
                                const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
  current_ = {};
}

void SnappingController::Detach() noexcept {
  HideMarker();
  current_ = {};
  view_.Nullify();
  context_.Nullify();
}

const SnapResult& SnappingController::UpdateAt(int mouseX, int mouseY) {
  current_ = {};
  if (context_.IsNull() || view_.IsNull()) return current_;

  // Der Fang wird immer aus der aktuellen Mausposition neu ermittelt.
  // Beim Wegziehen faellt der Kandidat dadurch sofort aus dem Fangradius.
  context_->MoveTo(mouseX, mouseY, view_, Standard_False);
  if (!context_->HasDetectedShape()) {
    HideMarker();
    return current_;
  }

  const TopoDS_Shape detected = context_->DetectedShape();
  if (detected.IsNull()) {
    HideMarker();
    return current_;
  }

  SnapResult best{};
  best.distancePixels = std::numeric_limits<double>::infinity();

  // Prioritaet entsteht ueber den kleinsten Bildschirmabstand. Vertex, Mittelpunkt
  // und die echte Edge werden aus OCCT-Topologie abgeleitet, nicht aus Renderdreiecken.
  ConsiderVertex(detected, mouseX, mouseY, best);
  ConsiderEdge(detected, mouseX, mouseY, best);

  // Bei einer Face auch deren echte Unterformen pruefen.
  if (detected.ShapeType() == TopAbs_FACE || detected.ShapeType() == TopAbs_SHELL ||
      detected.ShapeType() == TopAbs_SOLID || detected.ShapeType() == TopAbs_COMPOUND) {
    for (TopExp_Explorer ex(detected, TopAbs_VERTEX); ex.More(); ex.Next()) {
      ConsiderVertex(ex.Current(), mouseX, mouseY, best);
    }
    for (TopExp_Explorer ex(detected, TopAbs_EDGE); ex.More(); ex.Next()) {
      ConsiderEdge(ex.Current(), mouseX, mouseY, best);
    }
  }

  if (best.kind == SnapKind::None || best.distancePixels > snapRadiusPixels_) {
    HideMarker();
    current_ = {};
    return current_;
  }

  current_ = best;
  ShowMarker(current_);
  return current_;
}

bool SnappingController::ConsiderVertex(const TopoDS_Shape& shape,
                                        int mouseX,
                                        int mouseY,
                                        SnapResult& best) const {
  if (shape.IsNull() || shape.ShapeType() != TopAbs_VERTEX) return false;
  const gp_Pnt point = BRep_Tool::Pnt(TopoDS::Vertex(shape));
  int sx = 0, sy = 0;
  if (!ProjectPoint(point, sx, sy)) return false;
  const double distance = DistancePixels(mouseX, mouseY, sx, sy);
  AcceptCandidate(best, SnapKind::Vertex, point, sx, sy, distance, L"Vertex / Endpunkt");
  return true;
}

bool SnappingController::ConsiderEdge(const TopoDS_Shape& shape,
                                      int mouseX,
                                      int mouseY,
                                      SnapResult& best) const {
  if (shape.IsNull() || shape.ShapeType() != TopAbs_EDGE) return false;

  const TopoDS_Edge edge = TopoDS::Edge(shape);
  BRepAdaptor_Curve curve(edge);
  const double first = curve.FirstParameter();
  const double last = curve.LastParameter();
  if (!std::isfinite(first) || !std::isfinite(last) || first == last) return false;

  // Echter geometrischer Mittelpunkt der parametrischen OCCT-Kante.
  const double midParam = first + (last - first) * 0.5;
  const gp_Pnt midpoint = curve.Value(midParam);
  int mx = 0, my = 0;
  if (ProjectPoint(midpoint, mx, my)) {
    const double distance = DistancePixels(mouseX, mouseY, mx, my);
    AcceptCandidate(best, SnapKind::Midpoint, midpoint, mx, my, distance, L"Mittelpunkt");
  }

  // Fuer den Kantenfang wird auf der echten OCCT-Kurve gesucht. Gerade Kanten sind
  // damit fuer den aktuellen Holzbau-Kern praezise; Kurven werden in v0.006 mit dem
  // Bogenmodul weiter gehaertet.
  constexpr int kSamples = 32;
  for (int i = 0; i <= kSamples; ++i) {
    const double t = first + (last - first) * (static_cast<double>(i) / kSamples);
    const gp_Pnt p = curve.Value(t);
    int sx = 0, sy = 0;
    if (!ProjectPoint(p, sx, sy)) continue;
    const double distance = DistancePixels(mouseX, mouseY, sx, sy);
    AcceptCandidate(best, SnapKind::Edge, p, sx, sy, distance, L"Kante");
  }
  return true;
}

bool SnappingController::ProjectPoint(const gp_Pnt& p, int& x, int& y) const {
  if (view_.IsNull()) return false;
  Standard_Integer sx = 0;
  Standard_Integer sy = 0;
  view_->Convert(p.X(), p.Y(), p.Z(), sx, sy);
  x = static_cast<int>(sx);
  y = static_cast<int>(sy);
  return true;
}

void SnappingController::ShowMarker(const SnapResult& result) {
  if (context_.IsNull()) return;
  HideMarker();

  Handle(Geom_CartesianPoint) point = new Geom_CartesianPoint(result.point);
  Handle(AIS_Point) marker = new AIS_Point(point);
  marker->SetColor(Quantity_NOC_RED);
  context_->Display(marker, Standard_False);
  context_->Deactivate(marker);
  marker_ = marker;
  context_->UpdateCurrentViewer();
}

void SnappingController::HideMarker() {
  if (!context_.IsNull() && !marker_.IsNull()) {
    context_->Remove(marker_, Standard_False);
    marker_.Nullify();
    context_->UpdateCurrentViewer();
  } else {
    marker_.Nullify();
  }
}

void SnappingController::Clear() {
  current_ = {};
  HideMarker();
}

}
