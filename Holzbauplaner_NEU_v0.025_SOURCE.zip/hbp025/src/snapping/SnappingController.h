#pragma once

#include <AIS_InteractiveContext.hxx>
#include <AIS_InteractiveObject.hxx>
#include <TopoDS_Shape.hxx>
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>

namespace hbp::snapping {

enum class SnapKind {
  None,
  Vertex,
  Edge,
  Midpoint
};

struct SnapResult {
  SnapKind kind = SnapKind::None;
  gp_Pnt point{};
  int screenX = 0;
  int screenY = 0;
  double distancePixels = 0.0;
  std::wstring label = L"Kein Fang";

  explicit operator bool() const noexcept { return kind != SnapKind::None; }
};

class SnappingController {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context,
              const Handle(V3d_View)& view);
  void Detach() noexcept;

  // Rechnet bei jeder Mausbewegung neu. Es gibt bewusst keinen klebenden Snap-Zustand.
  const SnapResult& UpdateAt(int mouseX, int mouseY);
  void Clear();

  const SnapResult& Current() const noexcept { return current_; }
  void SetSnapRadiusPixels(double radius) noexcept { snapRadiusPixels_ = radius; }

private:
  bool ConsiderVertex(const TopoDS_Shape& shape, int mouseX, int mouseY, SnapResult& best) const;
  bool ConsiderEdge(const TopoDS_Shape& shape, int mouseX, int mouseY, SnapResult& best) const;
  bool ProjectPoint(const gp_Pnt& p, int& x, int& y) const;
  void ShowMarker(const SnapResult& result);
  void HideMarker();

  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  Handle(AIS_InteractiveObject) marker_;
  SnapResult current_{};
  double snapRadiusPixels_ = 12.0;
};

}
