#include "viewer/OcctViewer.h"

#include <AIS_Shape.hxx>
#include <Aspect_GridType.hxx>
#include <Aspect_GridDrawMode.hxx>
#include <Aspect_Grid.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <Quantity_Color.hxx>
#include <gp_Trsf.hxx>
#include <V3d_TypeOfOrientation.hxx>
#include <WNT_Window.hxx>
#include <TopoDS.hxx>

namespace hbp::viewer {

bool OcctViewer::Attach(HWND hwnd, document::DocumentModel* document) {
  if (!hwnd) return false;
  hwnd_ = hwnd;
  document_ = document;

  display_ = new Aspect_DisplayConnection();
  driver_ = new OpenGl_GraphicDriver(display_);
  viewer_ = new V3d_Viewer(driver_);
  viewer_->SetDefaultLights();
  viewer_->SetLightOn();

  context_ = new AIS_InteractiveContext(viewer_);
  view_ = viewer_->CreateView();

  Handle(WNT_Window) window = new WNT_Window(reinterpret_cast<Aspect_Handle>(hwnd_));
  view_->SetWindow(window);
  if (!window->IsMapped()) window->Map();

  view_->SetBackgroundColor(Quantity_NOC_WHITE);
  view_->SetProj(V3d_XposYnegZpos);

  selection_.Attach(context_, view_);
  snapping_.Attach(context_, view_);
  rectangle_.Attach(context_, view_);
  circle_.Attach(context_, view_);
  arc_.Attach(context_, view_);
  pencil_.Attach(context_, view_);
  constructionLines_.Attach(context_, view_);
  measure_.Attach(view_);
  angle_.Attach(view_);
  DisplayViewerReference();
  if (document_) {
    for (const auto& shape : document_->Shapes()) DisplayModelShape(shape);
  }
  FitAll();

  attached_ = true;
  view_->Redraw();
  return true;
}

void OcctViewer::DisplayViewerReference() {
  if (context_.IsNull() || viewer_.IsNull() || view_.IsNull()) return;

  const TopoDS_Shape box = BRepPrimAPI_MakeBox(1200.0, 600.0, 120.0).Shape();
  referencePresentation_ = new AIS_Shape(box);
  referencePresentation_->SetColor(Quantity_Color(0.80, 0.73, 0.61, Quantity_TOC_RGB));
  referencePresentation_->SetDisplayMode(AIS_Shaded);
  context_->Display(referencePresentation_, Standard_False);
  selection_.ConfigureSelectableObject(referencePresentation_);

  viewer_->SetRectangularGridValues(0.0, 0.0, 100.0, 100.0, 0.0);
  Handle(Aspect_Grid) grid = viewer_->Grid(Aspect_GT_Rectangular, Standard_True);
  if (!grid.IsNull()) {
    grid->SetColors(Quantity_Color(0.90, 0.91, 0.93, Quantity_TOC_RGB),
                    Quantity_Color(0.78, 0.80, 0.83, Quantity_TOC_RGB));
  }
  if (gridVisible_) viewer_->ActivateGrid(Aspect_GT_Rectangular, Aspect_GDM_Lines);
  else viewer_->DeactivateGrid();

  view_->TriedronDisplay(Aspect_TOTP_LEFT_LOWER,
                        Quantity_NOC_GRAY40,
                        0.075,
                        V3d_ZBUFFER);
  ApplyReferenceDisplayMode();
}

void OcctViewer::ApplyModelPresentationStyle(const Handle(AIS_Shape)& presentation) {
  if (presentation.IsNull()) return;
  presentation->SetColor(Quantity_Color(0.76, 0.68, 0.54, Quantity_TOC_RGB));
  presentation->SetDisplayMode(AIS_Shaded);
  if (xrayEnabled_) presentation->SetTransparency(0.72);
  else presentation->UnsetTransparency();
}

void OcctViewer::DisplayModelShape(const TopoDS_Shape& shape) {
  if (context_.IsNull() || shape.IsNull()) return;
  Handle(AIS_Shape) presentation = new AIS_Shape(shape);
  ApplyModelPresentationStyle(presentation);
  context_->Display(presentation, Standard_False);
  selection_.ConfigureSelectableObject(presentation);
  modelPresentations_.push_back({shape, presentation});
  if (explodedEnabled_) ApplyExplodedView();
  else context_->UpdateCurrentViewer();
}

void OcctViewer::RemoveModelShapePresentation(const TopoDS_Shape& shape) {
  if (context_.IsNull() || shape.IsNull()) return;
  for (auto it = modelPresentations_.begin(); it != modelPresentations_.end(); ++it) {
    if (it->shape.IsSame(shape)) {
      if (!it->ais.IsNull()) context_->Remove(it->ais, Standard_False);
      modelPresentations_.erase(it);
      context_->UpdateCurrentViewer();
      return;
    }
  }
}

void OcctViewer::ApplyExplodedView() {
  if (context_.IsNull()) return;

  // Always clear previous presentation-only transforms first.
  for (auto& item : modelPresentations_) {
    if (!item.ais.IsNull()) { gp_Trsf identity; item.ais->SetLocalTransformation(identity); }
  }

  if (!explodedEnabled_ || !document_) {
    context_->UpdateCurrentViewer();
    return;
  }

  const auto transforms = explodedView_.Build(document_->Parts());
  for (const auto& transform : transforms) {
    for (auto& item : modelPresentations_) {
      if (item.shape.IsNull() || item.ais.IsNull()) continue;
      if (!item.shape.IsSame(transform.shape)) continue;
      gp_Trsf trsf;
      trsf.SetTranslation(transform.translation);
      item.ais->SetLocalTransformation(trsf);
      break;
    }
  }
  context_->UpdateCurrentViewer();
}

void OcctViewer::ToggleExplodedView() {
  explodedEnabled_ = !explodedEnabled_;
  ApplyExplodedView();
  if (explodedEnabled_) FitAll();
}

void OcctViewer::Resize() {
  if (!attached_ || view_.IsNull()) return;
  view_->MustBeResized();
  view_->Redraw();
}

void OcctViewer::Redraw() {
  if (attached_ && !view_.IsNull()) view_->Redraw();
}

void OcctViewer::ReloadDocument() {
  if (context_.IsNull()) return;
  ActivateSelectionTool();
  selection_.ClearSelection();
  for (auto& item : modelPresentations_) {
    if (!item.ais.IsNull()) context_->Remove(item.ais, Standard_False);
  }
  modelPresentations_.clear();
  if (document_) {
    for (const auto& shape : document_->Shapes()) DisplayModelShape(shape);
  }
  if (explodedEnabled_) ApplyExplodedView();
  else context_->UpdateCurrentViewer();
  FitAll();
}

void OcctViewer::FitAll() {
  if (view_.IsNull()) return;
  view_->FitAll(0.08, Standard_True);
  view_->ZFitAll();
}

void OcctViewer::BeginOrbit(int x, int y) {
  if (!attached_ || view_.IsNull()) return;
  view_->StartRotation(x, y, 0.4);
}

void OcctViewer::OrbitTo(int x, int y) {
  if (!attached_ || view_.IsNull()) return;
  view_->Rotation(x, y);
}

void OcctViewer::BeginPan(int x, int y) {
  panStartX_ = x;
  panStartY_ = y;
  if (!attached_ || view_.IsNull()) return;
  view_->Pan(0, 0, 1.0, Standard_True);
}

void OcctViewer::PanTo(int x, int y) {
  if (!attached_ || view_.IsNull()) return;
  const int dx = x - panStartX_;
  const int dy = y - panStartY_;
  view_->Pan(dx, -dy, 1.0, Standard_False);
}

void OcctViewer::ZoomWheel(int, int, short wheelDelta) {
  if (!attached_ || view_.IsNull() || wheelDelta == 0) return;
  const double factor = wheelDelta > 0 ? 1.12 : (1.0 / 1.12);
  view_->SetZoom(factor, Standard_True);
}

void OcctViewer::HoverAt(int x, int y) {
  if (!attached_) return;
  const bool drawing = rectangle_.IsActive() || circle_.IsActive() || arc_.IsActive() || pushPull_.IsActive() || pencil_.IsActive() || offset_.IsActive() || chamfer_.IsActive() || fillet_.IsActive() || constructionLines_.IsActive() || measure_.IsActive() || angle_.IsActive();
  if (!drawing) selection_.HoverAt(x, y);
  const auto& snap = snapping_.UpdateAt(x, y);
  const gp_Pnt* snapped = snap ? &snap.point : nullptr;
  if (rectangle_.IsActive()) rectangle_.Move(x, y, snapped);
  else if (circle_.IsActive()) circle_.Move(x, y, snapped);
  else if (arc_.IsActive()) arc_.Move(x, y, snapped);
  else if (pencil_.IsActive()) pencil_.Move(x, y, snapped);
  else if (constructionLines_.IsActive()) constructionLines_.Move(x, y, snapped);
}

bool OcctViewer::LeftClickAt(int x, int y) {
  if (!attached_) return false;
  if (constructionLines_.IsActive() || measure_.IsActive() || angle_.IsActive()) {
    const auto& snap = snapping_.UpdateAt(x, y);
    const gp_Pnt* snapped = snap ? &snap.point : nullptr;
    if (constructionLines_.IsActive()) return constructionLines_.Click(x, y, snapped);
    if (measure_.IsActive()) return measure_.Click(x, y, snapped);
    return angle_.Click(x, y, snapped);
  }
  if (delete_.IsActive()) {
    if (!SelectAt(x, y)) return false;
    const auto info = selection_.Current();
    if (info.kind != selection::SelectionKind::Edge || info.shape.IsNull()) return false;

    const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
    if (!document_ || !document_->ContainsShape(source)) return false;
    if (!delete_.DeleteEdge(source, TopoDS::Edge(info.shape))) return false;

    const TopoDS_Shape finished = delete_.TakeFinishedShape();
    if (finished.IsNull()) return false;
    if (!document_->ReplaceShape(source, finished)) return false;
    RemoveModelShapePresentation(source);
    DisplayModelShape(finished);
    selection_.ClearSelection();
    return true;
  }
  if (pushPull_.IsActive() || offset_.IsActive() || chamfer_.IsActive() || fillet_.IsActive()) return true;
  if (!rectangle_.IsActive() && !circle_.IsActive() && !arc_.IsActive() && !pencil_.IsActive()) return SelectAt(x, y);

  const auto& snap = snapping_.UpdateAt(x, y);
  const gp_Pnt* snapped = snap ? &snap.point : nullptr;
  bool handled = false;
  TopoDS_Shape finished;
  if (rectangle_.IsActive()) {
    handled = rectangle_.Click(x, y, snapped);
    finished = rectangle_.TakeFinishedShape();
  } else if (circle_.IsActive()) {
    handled = circle_.Click(x, y, snapped);
    finished = circle_.TakeFinishedShape();
  } else if (arc_.IsActive()) {
    handled = arc_.Click(x, y, snapped);
    finished = arc_.TakeFinishedShape();
  } else if (pencil_.IsActive()) {
    handled = pencil_.Click(x, y, snapped);
    finished = pencil_.TakeFinishedShape();
    if (!finished.IsNull()) {
      const TopoDS_Shape source = pencil_.SourceShape();
      bool replaced = false;
      if (document_) replaced = document_->ReplaceShape(source, finished);
      if (replaced) RemoveModelShapePresentation(source);
      if (!replaced && document_) document_->AddShape(finished);
      DisplayModelShape(finished);
      selection_.ClearSelection();
      return handled;
    }
  }
  if (!finished.IsNull()) {
    if (document_) document_->AddShape(finished);
    DisplayModelShape(finished);
  }
  return handled;
}

void OcctViewer::ActivateSelectionTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
}

void OcctViewer::ActivateRectangleTool() {
  selection_.ClearSelection();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  rectangle_.Activate();
}

void OcctViewer::ActivateCircleTool() {
  selection_.ClearSelection();
  rectangle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  circle_.Activate();
}

void OcctViewer::ActivateArcTool() {
  selection_.ClearSelection();
  rectangle_.Deactivate();
  circle_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  arc_.Activate();
}



bool OcctViewer::ActivatePencilTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  const auto& info = selection_.Current();
  if (info.kind != selection::SelectionKind::Face || info.shape.IsNull()) {
    pencil_.Deactivate();
    return false;
  }
  const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
  if (!document_ || !document_->ContainsShape(source)) {
    pencil_.Deactivate();
    return false;
  }
  return pencil_.Activate(TopoDS::Face(info.shape), info.ownerShape);
}


bool OcctViewer::ActivatePushPullTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  const auto& info = selection_.Current();
  if (info.kind != selection::SelectionKind::Face || info.shape.IsNull()) {
    pushPull_.Deactivate();
    return false;
  }
  const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
  if (!document_ || !document_->ContainsShape(source)) {
    pushPull_.Deactivate();
    return false;
  }
  pushPull_.Activate(info.shape, info.ownerShape);
  return true;
}

bool OcctViewer::ActivateOffsetTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  const auto& info = selection_.Current();
  if (info.kind != selection::SelectionKind::Face || info.shape.IsNull()) {
    offset_.Deactivate();
    return false;
  }
  const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
  if (!document_ || !document_->ContainsShape(source)) {
    offset_.Deactivate();
    return false;
  }
  return offset_.Activate(info.shape, info.ownerShape);
}

void OcctViewer::ActivateDeleteTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  selection_.ClearSelection();
  delete_.Activate();
}

bool OcctViewer::ActivateChamferTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  const auto& info = selection_.Current();
  if (info.kind != selection::SelectionKind::Edge || info.shape.IsNull()) {
    chamfer_.Deactivate();
    return false;
  }
  const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
  if (!document_ || !document_->ContainsShape(source)) {
    chamfer_.Deactivate();
    return false;
  }
  return chamfer_.Activate(source, TopoDS::Edge(info.shape));
}

bool OcctViewer::ActivateFilletTool() {
  rectangle_.Deactivate();
  circle_.Deactivate();
  arc_.Deactivate();
  pushPull_.Deactivate();
  pencil_.Deactivate();
  offset_.Deactivate();
  delete_.Deactivate();
  chamfer_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  snapping_.Clear();
  const auto& info = selection_.Current();
  if (info.kind != selection::SelectionKind::Edge || info.shape.IsNull()) {
    fillet_.Deactivate();
    return false;
  }
  const TopoDS_Shape source = info.ownerShape.IsNull() ? info.shape : info.ownerShape;
  if (!document_ || !document_->ContainsShape(source)) {
    fillet_.Deactivate();
    return false;
  }
  return fillet_.Activate(source, TopoDS::Edge(info.shape));
}

void OcctViewer::ActivateConstructionLineTool() {
  ActivateSelectionTool();
  selection_.ClearSelection();
  constructionLines_.Activate();
}

void OcctViewer::ActivateMeasureTool() {
  ActivateSelectionTool();
  selection_.ClearSelection();
  measure_.Activate();
}

void OcctViewer::ActivateAngleTool() {
  ActivateSelectionTool();
  selection_.ClearSelection();
  angle_.Activate();
}

bool OcctViewer::CommitRectangleDimensions(double widthMm, double heightMm) {
  if (!rectangle_.CommitDimensions(widthMm, heightMm)) return false;
  const TopoDS_Shape finished = rectangle_.TakeFinishedShape();
  if (!finished.IsNull()) {
    if (document_) document_->AddShape(finished);
    DisplayModelShape(finished);
    return true;
  }
  return false;
}



bool OcctViewer::CommitCircleRadius(double radiusMm) {
  if (!circle_.CommitRadius(radiusMm)) return false;
  const TopoDS_Shape finished = circle_.TakeFinishedShape();
  if (!finished.IsNull()) {
    if (document_) document_->AddShape(finished);
    DisplayModelShape(finished);
    return true;
  }
  return false;
}



bool OcctViewer::CommitPushPullDistance(double distanceMm) {
  if (!pushPull_.CommitDistance(distanceMm)) return false;
  const TopoDS_Shape source = pushPull_.SourceShape();
  const TopoDS_Shape finished = pushPull_.TakeFinishedShape();
  if (finished.IsNull()) return false;

  bool replaced = false;
  if (document_) replaced = document_->ReplaceShape(source, finished);
  if (replaced) RemoveModelShapePresentation(source);
  if (!replaced && document_) document_->AddShape(finished);
  DisplayModelShape(finished);
  selection_.ClearSelection();
  return true;
}

bool OcctViewer::CommitOffsetDistance(double distanceMm) {
  if (!offset_.CommitDistance(distanceMm)) return false;
  const TopoDS_Shape source = offset_.SourceShape();
  const TopoDS_Shape finished = offset_.TakeFinishedShape();
  if (finished.IsNull()) return false;

  bool replaced = false;
  if (document_) replaced = document_->ReplaceShape(source, finished);
  if (replaced) RemoveModelShapePresentation(source);
  if (!replaced && document_) document_->AddShape(finished);
  DisplayModelShape(finished);
  selection_.ClearSelection();
  return true;
}

bool OcctViewer::CommitChamferDistance(double distanceMm) {
  if (!chamfer_.CommitDistance(distanceMm)) return false;
  const TopoDS_Shape source = chamfer_.SourceShape();
  const TopoDS_Shape finished = chamfer_.TakeFinishedShape();
  if (finished.IsNull()) return false;
  if (!document_ || !document_->ReplaceShape(source, finished)) return false;
  RemoveModelShapePresentation(source);
  DisplayModelShape(finished);
  selection_.ClearSelection();
  return true;
}

bool OcctViewer::CommitFilletRadius(double radiusMm) {
  if (!fillet_.CommitRadius(radiusMm)) return false;
  const TopoDS_Shape source = fillet_.SourceShape();
  const TopoDS_Shape finished = fillet_.TakeFinishedShape();
  if (finished.IsNull()) return false;
  if (!document_ || !document_->ReplaceShape(source, finished)) return false;
  RemoveModelShapePresentation(source);
  DisplayModelShape(finished);
  selection_.ClearSelection();
  return true;
}

void OcctViewer::CancelActiveTool() {
  if (rectangle_.IsActive()) rectangle_.Cancel();
  if (circle_.IsActive()) circle_.Cancel();
  if (arc_.IsActive()) arc_.Cancel();
  if (pushPull_.IsActive()) pushPull_.Deactivate();
  if (pencil_.IsActive()) pencil_.Cancel();
  if (offset_.IsActive()) offset_.Deactivate();
  if (delete_.IsActive()) delete_.Deactivate();
  if (chamfer_.IsActive()) chamfer_.Deactivate();
  if (fillet_.IsActive()) fillet_.Deactivate();
  if (constructionLines_.IsActive()) constructionLines_.Cancel();
  if (measure_.IsActive()) measure_.Cancel();
  if (angle_.IsActive()) angle_.Cancel();
}

std::wstring OcctViewer::ActiveToolStatus() const {
  if (rectangle_.IsActive()) return rectangle_.StatusText();
  if (circle_.IsActive()) return circle_.StatusText();
  if (arc_.IsActive()) return arc_.StatusText();
  if (pushPull_.IsActive()) return pushPull_.StatusText();
  if (pencil_.IsActive()) return pencil_.StatusText();
  if (offset_.IsActive()) return offset_.StatusText();
  if (delete_.IsActive()) return delete_.StatusText();
  if (chamfer_.IsActive()) return chamfer_.StatusText();
  if (fillet_.IsActive()) return fillet_.StatusText();
  if (constructionLines_.IsActive()) return constructionLines_.StatusText();
  if (measure_.IsActive()) return measure_.StatusText();
  if (angle_.IsActive()) return angle_.StatusText();
  return L"Auswahl aktiv";
}

bool OcctViewer::SelectAt(int x, int y) {
  if (!attached_) return false;
  return selection_.SelectAt(x, y);
}

void OcctViewer::ClearSelection() {
  selection_.ClearSelection();
}

const selection::SelectionInfo& OcctViewer::CurrentSelection() const noexcept {
  return selection_.Current();
}

const snapping::SnapResult& OcctViewer::CurrentSnap() const noexcept {
  return snapping_.Current();
}


void OcctViewer::ToggleGrid() {
  if (viewer_.IsNull()) return;
  gridVisible_ = !gridVisible_;
  if (gridVisible_) viewer_->ActivateGrid(Aspect_GT_Rectangular, Aspect_GDM_Lines);
  else viewer_->DeactivateGrid();
  if (!view_.IsNull()) view_->Redraw();
}

void OcctViewer::ToggleXRay() {
  xrayEnabled_ = !xrayEnabled_;
  if (context_.IsNull()) return;
  for (auto& entry : modelPresentations_) {
    if (entry.ais.IsNull()) continue;
    ApplyModelPresentationStyle(entry.ais);
    context_->Redisplay(entry.ais, Standard_False);
  }
  context_->UpdateCurrentViewer();
}

void OcctViewer::ApplyReferenceDisplayMode() {
  if (context_.IsNull() || referencePresentation_.IsNull()) return;
  switch (referenceMode_) {
    case ReferenceDisplayMode::Normal:
      referencePresentation_->UnsetTransparency();
      context_->Display(referencePresentation_, Standard_False);
      break;
    case ReferenceDisplayMode::Ghost:
      referencePresentation_->SetTransparency(0.82);
      context_->Display(referencePresentation_, Standard_False);
      context_->Redisplay(referencePresentation_, Standard_False);
      break;
    case ReferenceDisplayMode::Off:
      context_->Erase(referencePresentation_, Standard_False);
      break;
  }
  context_->UpdateCurrentViewer();
}

void OcctViewer::CycleReferenceDisplay() {
  if (referenceMode_ == ReferenceDisplayMode::Normal) referenceMode_ = ReferenceDisplayMode::Ghost;
  else if (referenceMode_ == ReferenceDisplayMode::Ghost) referenceMode_ = ReferenceDisplayMode::Off;
  else referenceMode_ = ReferenceDisplayMode::Normal;
  ApplyReferenceDisplayMode();
}

std::wstring OcctViewer::ReferenceModeLabel() const {
  switch (referenceMode_) {
    case ReferenceDisplayMode::Normal: return L"Normal";
    case ReferenceDisplayMode::Ghost: return L"Geister";
    case ReferenceDisplayMode::Off: return L"Aus";
  }
  return L"Normal";
}

void OcctViewer::Detach() noexcept {
  chamfer_.Deactivate();
  fillet_.Deactivate();
  constructionLines_.Deactivate();
  measure_.Deactivate();
  angle_.Deactivate();
  delete_.Deactivate();
  pushPull_.Deactivate();
  constructionLines_.Detach();
  measure_.Detach();
  angle_.Detach();
  pencil_.Detach();
  arc_.Detach();
  circle_.Detach();
  rectangle_.Detach();
  snapping_.Detach();
  selection_.Detach();
  modelPresentations_.clear();
  referencePresentation_.Nullify();
  attached_ = false;
  view_.Nullify();
  context_.Nullify();
  viewer_.Nullify();
  driver_.Nullify();
  display_.Nullify();
  hwnd_ = nullptr;
  document_ = nullptr;
}

}
