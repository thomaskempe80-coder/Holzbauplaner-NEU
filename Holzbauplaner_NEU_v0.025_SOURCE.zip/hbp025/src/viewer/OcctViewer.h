#pragma once
#include <windows.h>
#include <AIS_InteractiveContext.hxx>
#include <V3d_View.hxx>
#include <V3d_Viewer.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <AIS_Shape.hxx>
#include <vector>
#include "selection/SelectionController.h"
#include "snapping/SnappingController.h"
#include "inference/InferenceEngine.h"
#include "rectangle/RectangleTool.h"
#include "circle/CircleTool.h"
#include "arc/ArcTool.h"
#include "push-pull/PushPullTool.h"
#include "pencil/PencilTool.h"
#include "offset/OffsetTool.h"
#include "delete/DeleteTool.h"
#include "chamfer/ChamferTool.h"
#include "fillet/FilletTool.h"
#include "construction-lines/ConstructionLineTool.h"
#include "measure/MeasureTool.h"
#include "angle/AngleTool.h"
#include "document-model/DocumentModel.h"
#include "exploded-view/ExplodedView.h"

namespace hbp::viewer {

enum class ReferenceDisplayMode {
  Normal,
  Ghost,
  Off
};

class OcctViewer {
public:
  bool Attach(HWND hwnd, document::DocumentModel* document);
  void Resize();
  void Redraw();
  void FitAll();
  void ReloadDocument();
  void BeginOrbit(int x, int y);
  void OrbitTo(int x, int y);
  void BeginPan(int x, int y);
  void PanTo(int x, int y);
  void ZoomWheel(int x, int y, short wheelDelta);
  void HoverAt(int x, int y);
  bool LeftClickAt(int x, int y);
  bool SelectAt(int x, int y);
  void ActivateSelectionTool();
  void ActivateRectangleTool();
  void ActivateCircleTool();
  void ActivateArcTool();
  bool ActivatePushPullTool();
  bool ActivatePencilTool();
  bool ActivateOffsetTool();
  void ActivateDeleteTool();
  bool ActivateChamferTool();
  bool ActivateFilletTool();
  void ActivateConstructionLineTool();
  void ActivateMeasureTool();
  void ActivateAngleTool();
  bool RectangleActive() const noexcept { return rectangle_.IsActive(); }
  bool CircleActive() const noexcept { return circle_.IsActive(); }
  bool ArcActive() const noexcept { return arc_.IsActive(); }
  bool PushPullActive() const noexcept { return pushPull_.IsActive(); }
  bool PencilActive() const noexcept { return pencil_.IsActive(); }
  bool OffsetActive() const noexcept { return offset_.IsActive(); }
  bool DeleteActive() const noexcept { return delete_.IsActive(); }
  bool ChamferActive() const noexcept { return chamfer_.IsActive(); }
  bool FilletActive() const noexcept { return fillet_.IsActive(); }
  bool ConstructionLineActive() const noexcept { return constructionLines_.IsActive(); }
  bool MeasureActive() const noexcept { return measure_.IsActive(); }
  bool AngleActive() const noexcept { return angle_.IsActive(); }
  bool SelectionActive() const noexcept { return !RectangleActive() && !CircleActive() && !ArcActive() && !PushPullActive() && !PencilActive() && !OffsetActive() && !DeleteActive() && !ChamferActive() && !FilletActive() && !ConstructionLineActive() && !MeasureActive() && !AngleActive(); }
  bool CommitRectangleDimensions(double widthMm, double heightMm);
  bool CommitCircleRadius(double radiusMm);
  bool CommitPushPullDistance(double distanceMm);
  bool CommitOffsetDistance(double distanceMm);
  bool CommitChamferDistance(double distanceMm);
  bool CommitFilletRadius(double radiusMm);
  void CancelActiveTool();
  std::wstring ActiveToolStatus() const;
  void ClearSelection();
  const selection::SelectionInfo& CurrentSelection() const noexcept;
  const snapping::SnapResult& CurrentSnap() const noexcept;
  const inference::InferenceEngine& Inference() const noexcept { return inference_; }

  void ToggleGrid();
  void ToggleXRay();
  void CycleReferenceDisplay();
  bool GridVisible() const noexcept { return gridVisible_; }
  bool XRayEnabled() const noexcept { return xrayEnabled_; }
  ReferenceDisplayMode ReferenceMode() const noexcept { return referenceMode_; }
  std::wstring ReferenceModeLabel() const;

  void ToggleExplodedView();
  bool ExplodedViewEnabled() const noexcept { return explodedEnabled_; }

  void Detach() noexcept;
  bool IsAttached() const noexcept { return attached_; }

private:
  void DisplayViewerReference();
  void DisplayModelShape(const TopoDS_Shape& shape);
  void RemoveModelShapePresentation(const TopoDS_Shape& shape);
  void ApplyModelPresentationStyle(const Handle(AIS_Shape)& presentation);
  void ApplyReferenceDisplayMode();
  void ApplyExplodedView();

  HWND hwnd_ = nullptr;
  document::DocumentModel* document_ = nullptr;
  bool attached_ = false;
  int panStartX_ = 0;
  int panStartY_ = 0;
  Handle(Aspect_DisplayConnection) display_;
  Handle(OpenGl_GraphicDriver) driver_;
  Handle(V3d_Viewer) viewer_;
  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  selection::SelectionController selection_;
  snapping::SnappingController snapping_;
  inference::InferenceEngine inference_;
  rectangle::RectangleTool rectangle_;
  circle::CircleTool circle_;
  arc::ArcTool arc_;
  pushpull::PushPullTool pushPull_;
  pencil::PencilTool pencil_;
  offset::OffsetTool offset_;
  delete_tool::DeleteTool delete_;
  chamfer::ChamferTool chamfer_;
  fillet::FilletTool fillet_;
  construction_lines::ConstructionLineTool constructionLines_;
  measure::MeasureTool measure_;
  angle::AngleTool angle_;
  exploded_view::ExplodedView explodedView_;

  struct ModelPresentation { TopoDS_Shape shape; Handle(AIS_Shape) ais; };
  std::vector<ModelPresentation> modelPresentations_;
  Handle(AIS_Shape) referencePresentation_;
  bool gridVisible_ = true;
  bool xrayEnabled_ = false;
  ReferenceDisplayMode referenceMode_ = ReferenceDisplayMode::Normal;
  bool explodedEnabled_ = false;
};
}
