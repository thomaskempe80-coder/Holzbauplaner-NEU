#include "arc/ArcTool.h"

#include <BRepBuilderAPI_MakeEdge.hxx>
#include <GC_MakeArcOfCircle.hxx>
#include <Geom_TrimmedCurve.hxx>
#include <Quantity_Color.hxx>
#include <cmath>

namespace hbp::arc {
void ArcTool::Attach(const Handle(AIS_InteractiveContext)& context,
                     const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
}

void ArcTool::Detach() noexcept {
  Cancel();
  finished_.Nullify();
  view_.Nullify();
  context_.Nullify();
}

void ArcTool::Activate() {
  active_ = true;
  stage_ = 0;
  RemovePreview();
}

void ArcTool::Deactivate() {
  Cancel();
  active_ = false;
}

bool ArcTool::PointOnPlane(int x, int y, gp_Pnt& point) const {
  if (view_.IsNull()) return false;
  Standard_Real px=0.0, py=0.0, pz=0.0, vx=0.0, vy=0.0, vz=0.0;
  view_->ConvertWithProj(x, y, px, py, pz, vx, vy, vz);
  if (std::abs(vz) < 1.0e-12) return false;
  const double planeZ = stage_ > 0 ? p1_.Z() : 0.0;
  const double t = (planeZ - pz) / vz;
  point = gp_Pnt(px + t*vx, py + t*vy, planeZ);
  return true;
}

bool ArcTool::Click(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_) return false;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnPlane(x, y, point)) return false;
  if (stage_ > 0) point.SetZ(p1_.Z());

  if (stage_ == 0) {
    p1_ = point;
    last_ = point;
    stage_ = 1;
    return true;
  }
  if (stage_ == 1) {
    if (p1_.Distance(point) < 0.01) return false;
    p2_ = point;
    last_ = point;
    stage_ = 2;
    return true;
  }
  if (!BuildArc(p1_, p2_, point, false)) return false;
  stage_ = 0;
  RemovePreview();
  return true;
}

void ArcTool::Move(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_ || stage_ == 0) return;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnPlane(x, y, point)) return;
  point.SetZ(p1_.Z());
  last_ = point;

  if (stage_ == 2) BuildArc(p1_, p2_, point, true);
}

bool ArcTool::BuildArc(const gp_Pnt& start, const gp_Pnt& through, const gp_Pnt& end, bool preview) {
  if (start.Distance(through) < 0.01 || through.Distance(end) < 0.01 || start.Distance(end) < 0.01) return false;
  GC_MakeArcOfCircle arcMaker(start, through, end);
  if (!arcMaker.IsDone()) return false;
  Handle(Geom_TrimmedCurve) curve = arcMaker.Value();
  BRepBuilderAPI_MakeEdge edgeMaker(curve);
  if (!edgeMaker.IsDone()) return false;
  const TopoDS_Shape edge = edgeMaker.Edge();

  Handle(AIS_Shape) presentation = new AIS_Shape(edge);
  presentation->SetColor(preview
      ? Quantity_Color(0.30,0.58,0.86,Quantity_TOC_RGB)
      : Quantity_Color(0.35,0.25,0.16,Quantity_TOC_RGB));
  presentation->SetWidth(preview ? 2.0 : 2.2);

  if (preview) {
    RemovePreview();
    preview_ = presentation;
    if (!context_.IsNull()) {
      context_->Display(preview_, Standard_False);
      context_->Deactivate(preview_);
      context_->UpdateCurrentViewer();
    }
  } else {
    finished_ = edge;
  }
  return true;
}

void ArcTool::RemovePreview() {
  if (!context_.IsNull() && !preview_.IsNull()) {
    context_->Remove(preview_, Standard_False);
    context_->UpdateCurrentViewer();
  }
  preview_.Nullify();
}

void ArcTool::Cancel() {
  stage_ = 0;
  RemovePreview();
}

std::wstring ArcTool::StatusText() const {
  if (!active_) return L"Bogen inaktiv";
  if (stage_ == 0) return L"Bogen: Startpunkt anklicken";
  if (stage_ == 1) return L"Bogen: Punkt auf dem Bogen anklicken";
  return L"Bogen: Endpunkt anklicken";
}

TopoDS_Shape ArcTool::TakeFinishedShape() {
  TopoDS_Shape out = finished_;
  finished_.Nullify();
  return out;
}
}
