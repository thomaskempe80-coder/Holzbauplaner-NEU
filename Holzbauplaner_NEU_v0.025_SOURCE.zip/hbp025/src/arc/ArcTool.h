#pragma once
#include <AIS_InteractiveContext.hxx>
#include <AIS_Shape.hxx>
#include <V3d_View.hxx>
#include <TopoDS_Shape.hxx>
#include <gp_Pnt.hxx>
#include <string>

namespace hbp::arc {
class ArcTool {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context, const Handle(V3d_View)& view);
  void Detach() noexcept;
  void Activate();
  void Deactivate();
  bool IsActive() const noexcept { return active_; }
  bool Click(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Move(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Cancel();
  std::wstring StatusText() const;
  TopoDS_Shape TakeFinishedShape();

private:
  bool PointOnPlane(int x, int y, gp_Pnt& point) const;
  bool BuildArc(const gp_Pnt& start, const gp_Pnt& through, const gp_Pnt& end, bool preview);
  void RemovePreview();

  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  Handle(AIS_Shape) preview_;
  TopoDS_Shape finished_;
  gp_Pnt p1_;
  gp_Pnt p2_;
  gp_Pnt last_;
  int stage_ = 0;
  bool active_ = false;
};
}
