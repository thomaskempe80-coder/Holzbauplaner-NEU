#include "circle/CircleTool.h"

#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <Geom_Circle.hxx>
#include <gp_Ax2.hxx>
#include <gp_Circ.hxx>
#include <gp_Dir.hxx>
#include <Quantity_Color.hxx>
#include <cmath>

namespace hbp::circle {
namespace { constexpr double kMinRadiusMm = 0.01; }

void CircleTool::Attach(const Handle(AIS_InteractiveContext)& context,
                        const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
}

void CircleTool::Detach() noexcept {
  Cancel();
  finished_.Nullify();
  view_.Nullify();
  context_.Nullify();
}

void CircleTool::Activate() {
  active_ = true;
  hasCenter_ = false;
  RemovePreview();
}

void CircleTool::Deactivate() {
  Cancel();
  active_ = false;
}

bool CircleTool::PointOnPlane(int x, int y, gp_Pnt& point) const {
  if (view_.IsNull()) return false;
  Standard_Real px=0.0, py=0.0, pz=0.0, vx=0.0, vy=0.0, vz=0.0;
  view_->ConvertWithProj(x, y, px, py, pz, vx, vy, vz);
  if (std::abs(vz) < 1.0e-12) return false;
  const double planeZ = hasCenter_ ? center_.Z() : 0.0;
  const double t = (planeZ - pz) / vz;
  point = gp_Pnt(px + t*vx, py + t*vy, planeZ);
  return true;
}

bool CircleTool::Click(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_) return false;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnPlane(x, y, point)) return false;

  if (!hasCenter_) {
    center_ = point;
    last_ = point;
    hasCenter_ = true;
    return true;
  }
  point.SetZ(center_.Z());
  return FinishAt(point);
}

void CircleTool::Move(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_ || !hasCenter_) return;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnPlane(x, y, point)) return;
  point.SetZ(center_.Z());
  last_ = point;
  const double radius = center_.Distance(point);
  if (radius >= kMinRadiusMm) BuildCircle(center_, radius, true);
}

bool CircleTool::CommitRadius(double radiusMm) {
  if (!active_ || !hasCenter_ || radiusMm < kMinRadiusMm) return false;
  return BuildCircle(center_, radiusMm, false) ? (hasCenter_ = false, RemovePreview(), true) : false;
}

bool CircleTool::FinishAt(const gp_Pnt& edgePoint) {
  const double radius = center_.Distance(edgePoint);
  if (radius < kMinRadiusMm) return false;
  if (!BuildCircle(center_, radius, false)) return false;
  hasCenter_ = false;
  RemovePreview();
  return true;
}

bool CircleTool::BuildCircle(const gp_Pnt& center, double radius, bool preview) {
  gp_Ax2 axis(center, gp_Dir(0.0,0.0,1.0));
  gp_Circ circle(axis, radius);
  BRepBuilderAPI_MakeEdge edgeMaker(circle);
  if (!edgeMaker.IsDone()) return false;
  BRepBuilderAPI_MakeWire wireMaker(edgeMaker.Edge());
  if (!wireMaker.IsDone()) return false;
  BRepBuilderAPI_MakeFace faceMaker(wireMaker.Wire(), Standard_True);
  if (!faceMaker.IsDone()) return false;

  const TopoDS_Shape face = faceMaker.Face();
  Handle(AIS_Shape) presentation = new AIS_Shape(face);
  presentation->SetColor(preview
      ? Quantity_Color(0.72,0.82,0.92,Quantity_TOC_RGB)
      : Quantity_Color(0.76,0.68,0.54,Quantity_TOC_RGB));
  presentation->SetTransparency(preview ? 0.55 : 0.0);
  presentation->SetDisplayMode(AIS_Shaded);

  if (preview) {
    RemovePreview();
    preview_ = presentation;
    if (!context_.IsNull()) {
      context_->Display(preview_, Standard_False);
      context_->Deactivate(preview_);
      context_->UpdateCurrentViewer();
    }
  } else {
    finished_ = face;
  }
  return true;
}

void CircleTool::RemovePreview() {
  if (!context_.IsNull() && !preview_.IsNull()) {
    context_->Remove(preview_, Standard_False);
    context_->UpdateCurrentViewer();
  }
  preview_.Nullify();
}

void CircleTool::Cancel() {
  hasCenter_ = false;
  RemovePreview();
}

std::wstring CircleTool::StatusText() const {
  if (!active_) return L"Kreis inaktiv";
  if (!hasCenter_) return L"Kreis: Mittelpunkt anklicken";
  return L"Kreis: Radiuspunkt anklicken oder Radius eingeben";
}

TopoDS_Shape CircleTool::TakeFinishedShape() {
  TopoDS_Shape out = finished_;
  finished_.Nullify();
  return out;
}
}
