#include "rectangle/RectangleTool.h"

#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakePolygon.hxx>
#include <Quantity_Color.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Wire.hxx>
#include <cmath>
#include <sstream>

namespace hbp::rectangle {
namespace {
constexpr double kMinSizeMm = 0.01;
}

void RectangleTool::Attach(const Handle(AIS_InteractiveContext)& context,
                           const Handle(V3d_View)& view) {
  context_ = context;
  view_ = view;
}

void RectangleTool::Detach() noexcept {
  Cancel();
  finished_.Nullify();
  view_.Nullify();
  context_.Nullify();
}

void RectangleTool::Activate() {
  active_ = true;
  hasStart_ = false;
  RemovePreview();
}

void RectangleTool::Deactivate() {
  Cancel();
  active_ = false;
}

bool RectangleTool::PointOnGroundPlane(int x, int y, gp_Pnt& point) const {
  if (view_.IsNull()) return false;

  Standard_Real px = 0.0, py = 0.0, pz = 0.0;
  Standard_Real vx = 0.0, vy = 0.0, vz = 0.0;
  view_->ConvertWithProj(x, y, px, py, pz, vx, vy, vz);

  // Die aktuelle Basis nutzt eine horizontale XY-Konstruktionsebene. Der erste Punkt liegt
  // standardmaessig auf Z=0; ein gefangener erster Punkt kann die Ebene auf seine Z-Hoehe legen.
  if (std::abs(vz) < 1.0e-12) return false;
  const double planeZ = hasStart_ ? start_.Z() : 0.0;
  const double t = (planeZ - pz) / vz;
  point = gp_Pnt(px + t * vx, py + t * vy, planeZ);
  return true;
}

bool RectangleTool::Click(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_) return false;

  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnGroundPlane(x, y, point)) return false;

  if (hasStart_) point.SetZ(start_.Z());
  if (!hasStart_) {
    start_ = point;
    last_ = point;
    hasStart_ = true;
    return true;
  }
  return FinishAt(point);
}

void RectangleTool::Move(int x, int y, const gp_Pnt* snappedPoint) {
  if (!active_ || !hasStart_) return;
  gp_Pnt point;
  if (snappedPoint) point = *snappedPoint;
  else if (!PointOnGroundPlane(x, y, point)) return;
  point.SetZ(start_.Z());
  last_ = point;
  UpdatePreview(point);
}

bool RectangleTool::CommitDimensions(double widthMm, double heightMm) {
  if (!active_ || !hasStart_ || widthMm < kMinSizeMm || heightMm < kMinSizeMm) return false;

  const double sx = (last_.X() < start_.X()) ? -1.0 : 1.0;
  const double sy = (last_.Y() < start_.Y()) ? -1.0 : 1.0;
  gp_Pnt end(start_.X() + sx * widthMm, start_.Y() + sy * heightMm, start_.Z());
  return FinishAt(end);
}

bool RectangleTool::FinishAt(const gp_Pnt& current) {
  if (!BuildFace(start_, current, false)) return false;
  hasStart_ = false;
  RemovePreview();
  return true;
}

void RectangleTool::UpdatePreview(const gp_Pnt& current) {
  BuildFace(start_, current, true);
}

bool RectangleTool::BuildFace(const gp_Pnt& a, const gp_Pnt& b, bool preview) {
  const double width = std::abs(b.X() - a.X());
  const double height = std::abs(b.Y() - a.Y());
  if (width < kMinSizeMm || height < kMinSizeMm) return false;

  const double z = a.Z();
  const gp_Pnt p1(a.X(), a.Y(), z);
  const gp_Pnt p2(b.X(), a.Y(), z);
  const gp_Pnt p3(b.X(), b.Y(), z);
  const gp_Pnt p4(a.X(), b.Y(), z);

  BRepBuilderAPI_MakePolygon polygon;
  polygon.Add(p1); polygon.Add(p2); polygon.Add(p3); polygon.Add(p4); polygon.Close();
  if (!polygon.IsDone()) return false;
  const TopoDS_Wire wire = polygon.Wire();

  BRepBuilderAPI_MakeFace maker(wire, Standard_True);
  if (!maker.IsDone()) return false;
  const TopoDS_Face face = maker.Face();

  Handle(AIS_Shape) presentation = new AIS_Shape(face);
  presentation->SetColor(preview
      ? Quantity_Color(0.72, 0.82, 0.92, Quantity_TOC_RGB)
      : Quantity_Color(0.76, 0.68, 0.54, Quantity_TOC_RGB));
  presentation->SetTransparency(preview ? 0.55 : 0.0);
  presentation->SetDisplayMode(AIS_Shaded);

  if (preview) {
    RemovePreview();
    preview_ = presentation;
    if (!context_.IsNull()) {
      context_->Display(preview_, Standard_False);
      context_->Deactivate(preview_);
      context_->UpdateCurrentViewer();
    }
  } else {
    finished_ = face;
  }
  return true;
}

void RectangleTool::RemovePreview() {
  if (!context_.IsNull() && !preview_.IsNull()) {
    context_->Remove(preview_, Standard_False);
    context_->UpdateCurrentViewer();
  }
  preview_.Nullify();
}

void RectangleTool::Cancel() {
  hasStart_ = false;
  RemovePreview();
}

std::wstring RectangleTool::StatusText() const {
  if (!active_) return L"Rechteck inaktiv";
  if (!hasStart_) return L"Rechteck: Startpunkt anklicken";
  return L"Rechteck: zweiten Punkt anklicken oder Breite x Höhe eingeben";
}

TopoDS_Shape RectangleTool::TakeFinishedShape() {
  TopoDS_Shape out = finished_;
  finished_.Nullify();
  return out;
}

}
