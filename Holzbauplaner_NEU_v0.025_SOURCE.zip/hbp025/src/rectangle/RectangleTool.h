#pragma once

#include <AIS_InteractiveContext.hxx>
#include <AIS_Shape.hxx>
#include <TopoDS_Shape.hxx>
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>

namespace hbp::rectangle {

class RectangleTool {
public:
  void Attach(const Handle(AIS_InteractiveContext)& context,
              const Handle(V3d_View)& view);
  void Detach() noexcept;

  void Activate();
  void Deactivate();
  bool IsActive() const noexcept { return active_; }
  bool HasStartPoint() const noexcept { return hasStart_; }

  bool Click(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  void Move(int x, int y, const gp_Pnt* snappedPoint = nullptr);
  bool CommitDimensions(double widthMm, double heightMm);
  void Cancel();

  std::wstring StatusText() const;
  TopoDS_Shape TakeFinishedShape();

private:
  bool PointOnGroundPlane(int x, int y, gp_Pnt& point) const;
  void UpdatePreview(const gp_Pnt& current);
  bool FinishAt(const gp_Pnt& current);
  bool BuildFace(const gp_Pnt& a, const gp_Pnt& b, bool preview);
  void RemovePreview();

  Handle(AIS_InteractiveContext) context_;
  Handle(V3d_View) view_;
  Handle(AIS_Shape) preview_;
  TopoDS_Shape finished_;
  bool active_ = false;
  bool hasStart_ = false;
  gp_Pnt start_{};
  gp_Pnt last_{};
};

}
