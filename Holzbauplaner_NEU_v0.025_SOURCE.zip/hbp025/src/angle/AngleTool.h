#pragma once
#include <V3d_View.hxx>
#include <gp_Pnt.hxx>
#include <string>
namespace hbp::angle {
class AngleTool {
public:
  void Attach(const Handle(V3d_View)& view){view_=view;}
  void Detach() noexcept {view_.Nullify();active_=false;stage_=0;}
  void Activate(){active_=true;stage_=0;result_.clear();}
  void Deactivate(){active_=false;stage_=0;}
  bool IsActive() const noexcept{return active_;}
  bool Click(int x,int y,const gp_Pnt* snappedPoint=nullptr);
  void Cancel(){stage_=0;}
  std::wstring StatusText() const;
private:
  bool PointOnGroundPlane(int x,int y,gp_Pnt& point) const;
  Handle(V3d_View) view_; bool active_=false; int stage_=0; gp_Pnt a_{},vertex_{}; std::wstring result_;
};
}
