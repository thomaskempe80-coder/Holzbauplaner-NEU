#include "angle/AngleTool.h"
#include <gp_Vec.hxx>
#include <cmath>
#include <sstream>
#include <iomanip>
namespace hbp::angle {
bool AngleTool::PointOnGroundPlane(int x,int y,gp_Pnt& p) const { if(view_.IsNull())return false; Standard_Real px=0,py=0,pz=0,vx=0,vy=0,vz=0; view_->ConvertWithProj(x,y,px,py,pz,vx,vy,vz); if(std::abs(vz)<1e-12)return false; const double z=(stage_>0?a_.Z():0.0),t=(z-pz)/vz; p=gp_Pnt(px+t*vx,py+t*vy,z); return true; }
bool AngleTool::Click(int x,int y,const gp_Pnt* snap){ if(!active_)return false; gp_Pnt p; if(snap)p=*snap; else if(!PointOnGroundPlane(x,y,p))return false; if(stage_==0){a_=p;stage_=1;result_.clear();return true;} if(stage_==1){vertex_=p;stage_=2;return true;} gp_Vec v1(vertex_,a_),v2(vertex_,p); if(v1.Magnitude()<1e-9||v2.Magnitude()<1e-9)return false; double c=v1.Dot(v2)/(v1.Magnitude()*v2.Magnitude()); if(c>1)c=1;if(c<-1)c=-1; const double deg=std::acos(c)*180.0/3.14159265358979323846; std::wostringstream s;s<<L"Winkel: "<<std::fixed<<std::setprecision(2)<<deg<<L"°";result_=s.str();stage_=0;return true; }
std::wstring AngleTool::StatusText() const { if(!active_)return L"Winkel inaktiv"; if(stage_==0&&!result_.empty())return L"Winkel: "+result_+L"  •  neue Messung möglich"; if(stage_==0)return L"Winkel: ersten Schenkelpunkt anklicken"; if(stage_==1)return L"Winkel: Scheitelpunkt anklicken"; return L"Winkel: zweiten Schenkelpunkt anklicken"; }
}
