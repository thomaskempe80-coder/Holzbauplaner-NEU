#pragma once
#include "core/IModule.h"
#include <TopoDS_Shape.hxx>
#include <cstdint>
#include <string>
#include <vector>

namespace hbp::parts {

struct PartDimensions {
  double xMm = 0.0;
  double yMm = 0.0;
  double zMm = 0.0;
};

struct PartRecord {
  std::uint64_t numericId = 0;
  std::wstring id;
  std::wstring name;
  std::wstring type;
  std::wstring material = L"Nicht zugewiesen";
  TopoDS_Shape shape;
  PartDimensions dimensions;
};

struct PartStoreState {
  std::uint64_t nextId = 1;
  std::vector<PartRecord> parts;
};

class PartStore final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"parts"; }
  bool Initialize() override;
  void Shutdown() noexcept override;

  PartRecord* Add(const TopoDS_Shape& shape);
  bool ReplaceShape(const TopoDS_Shape& oldShape, const TopoDS_Shape& newShape);
  bool Contains(const TopoDS_Shape& shape) const;
  PartRecord* Find(const TopoDS_Shape& shape);
  const PartRecord* Find(const TopoDS_Shape& shape) const;
  const std::vector<PartRecord>& All() const noexcept { return parts_; }
  std::vector<TopoDS_Shape> Shapes() const;
  PartStoreState CaptureState() const;
  void RestoreState(const PartStoreState& state);

private:
  static std::wstring ShapeTypeName(const TopoDS_Shape& shape);
  static PartDimensions Measure(const TopoDS_Shape& shape);
  static std::wstring MakeId(std::uint64_t value);
  static std::wstring MakeName(std::uint64_t value);
  void Refresh(PartRecord& part);

  std::uint64_t nextId_ = 1;
  std::vector<PartRecord> parts_;
};

} // namespace hbp::parts
