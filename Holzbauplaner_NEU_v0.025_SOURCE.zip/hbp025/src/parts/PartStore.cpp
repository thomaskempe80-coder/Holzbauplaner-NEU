#include "parts/PartStore.h"

#include <Bnd_Box.hxx>
#include <BRepBndLib.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace hbp::parts {

bool PartStore::Initialize() {
  parts_.clear();
  nextId_ = 1;
  return true;
}

void PartStore::Shutdown() noexcept {
  parts_.clear();
  nextId_ = 1;
}

PartRecord* PartStore::Add(const TopoDS_Shape& shape) {
  if (shape.IsNull()) return nullptr;
  PartRecord part;
  part.numericId = nextId_++;
  part.id = MakeId(part.numericId);
  part.name = MakeName(part.numericId);
  part.shape = shape;
  Refresh(part);
  parts_.push_back(part);
  return &parts_.back();
}

bool PartStore::ReplaceShape(const TopoDS_Shape& oldShape, const TopoDS_Shape& newShape) {
  if (oldShape.IsNull() || newShape.IsNull()) return false;
  PartRecord* part = Find(oldShape);
  if (!part) return false;
  part->shape = newShape;
  Refresh(*part);
  return true;
}

bool PartStore::Contains(const TopoDS_Shape& shape) const {
  return Find(shape) != nullptr;
}

PartRecord* PartStore::Find(const TopoDS_Shape& shape) {
  if (shape.IsNull()) return nullptr;
  for (auto& part : parts_) {
    if (!part.shape.IsNull() && part.shape.IsSame(shape)) return &part;
  }
  return nullptr;
}

const PartRecord* PartStore::Find(const TopoDS_Shape& shape) const {
  if (shape.IsNull()) return nullptr;
  for (const auto& part : parts_) {
    if (!part.shape.IsNull() && part.shape.IsSame(shape)) return &part;
  }
  return nullptr;
}

std::vector<TopoDS_Shape> PartStore::Shapes() const {
  std::vector<TopoDS_Shape> result;
  result.reserve(parts_.size());
  for (const auto& part : parts_) result.push_back(part.shape);
  return result;
}

PartStoreState PartStore::CaptureState() const {
  PartStoreState state;
  state.nextId = nextId_;
  state.parts = parts_;
  return state;
}

void PartStore::RestoreState(const PartStoreState& state) {
  parts_ = state.parts;
  nextId_ = std::max<std::uint64_t>(1, state.nextId);
  for (auto& part : parts_) Refresh(part);
}

std::wstring PartStore::ShapeTypeName(const TopoDS_Shape& shape) {
  switch (shape.ShapeType()) {
    case TopAbs_COMPOUND:  return L"Verbund";
    case TopAbs_COMPSOLID: return L"Mehrfachkörper";
    case TopAbs_SOLID:     return L"Körper";
    case TopAbs_SHELL:     return L"Hülle";
    case TopAbs_FACE:      return L"Fläche";
    case TopAbs_WIRE:      return L"Kontur";
    case TopAbs_EDGE:      return L"Kante";
    case TopAbs_VERTEX:    return L"Punkt";
    default:               return L"Geometrie";
  }
}

PartDimensions PartStore::Measure(const TopoDS_Shape& shape) {
  PartDimensions dimensions;
  if (shape.IsNull()) return dimensions;

  Bnd_Box box;
  BRepBndLib::Add(shape, box);
  if (box.IsVoid()) return dimensions;

  Standard_Real xmin = 0.0, ymin = 0.0, zmin = 0.0;
  Standard_Real xmax = 0.0, ymax = 0.0, zmax = 0.0;
  box.Get(xmin, ymin, zmin, xmax, ymax, zmax);
  dimensions.xMm = std::max(0.0, static_cast<double>(xmax - xmin));
  dimensions.yMm = std::max(0.0, static_cast<double>(ymax - ymin));
  dimensions.zMm = std::max(0.0, static_cast<double>(zmax - zmin));
  return dimensions;
}

std::wstring PartStore::MakeId(std::uint64_t value) {
  std::wostringstream out;
  out << L"P" << std::setfill(L'0') << std::setw(4) << value;
  return out.str();
}

std::wstring PartStore::MakeName(std::uint64_t value) {
  std::wostringstream out;
  out << L"Bauteil " << std::setfill(L'0') << std::setw(3) << value;
  return out.str();
}

void PartStore::Refresh(PartRecord& part) {
  part.type = ShapeTypeName(part.shape);
  part.dimensions = Measure(part.shape);
}

} // namespace hbp::parts
