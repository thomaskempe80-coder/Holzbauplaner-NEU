#include "app/Application.h"
#include <windows.h>

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand) {
  hbp::app::Application app;
  return app.Run(instance,showCommand);
}
