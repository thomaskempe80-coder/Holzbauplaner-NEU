#include "app/Application.h"
#include "cad-kernel/CadKernel.h"
#include "document-model/DocumentModel.h"
#include "ui/MainWindow.h"
#include <memory>

namespace hbp::app {
int Application::Run(HINSTANCE instance, int showCommand) {
  modules_.Add(std::make_unique<cad::CadKernel>());
  auto documentModule = std::make_unique<document::DocumentModel>();
  auto* document = documentModule.get();
  modules_.Add(std::move(documentModule));
  if (!modules_.InitializeAll()) {
    MessageBoxW(nullptr,L"Der OCCT-Kern konnte nicht initialisiert werden.",L"Holzbauplaner v0.025",MB_ICONERROR|MB_OK);
    return 2;
  }
  ui::MainWindow window;
  if (!window.Create(instance,showCommand,document)) {
    modules_.ShutdownAll();
    return 3;
  }
  const int code = window.Run();
  modules_.ShutdownAll();
  return code;
}
}
