#pragma once
namespace hbp::app {
inline constexpr wchar_t kVersion[] = L"0.025";
inline constexpr wchar_t kProductName[] = L"Holzbauplaner NEU";
}
