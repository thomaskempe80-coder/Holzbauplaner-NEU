#pragma once
#include <windows.h>
#include "core/ModuleRegistry.h"

namespace hbp::app {
class Application {
public:
  int Run(HINSTANCE instance, int showCommand);
private:
  core::ModuleRegistry modules_;
};
}
