#pragma once
#include "core/IModule.h"

namespace hbp::cad {
class CadKernel final : public core::IModule {
public:
  std::wstring_view Id() const noexcept override { return L"cad-kernel"; }
  bool Initialize() override;
  void Shutdown() noexcept override;
  bool IsReady() const noexcept { return ready_; }
private:
  bool ready_ = false;
};
}
