#include "cad-kernel/CadKernel.h"
#include <Standard_Version.hxx>

namespace hbp::cad {
bool CadKernel::Initialize() {
  // Linking/loading OCCT itself is the first kernel check.
  ready_ = OCC_VERSION_HEX > 0;
  return ready_;
}
void CadKernel::Shutdown() noexcept { ready_ = false; }
}
