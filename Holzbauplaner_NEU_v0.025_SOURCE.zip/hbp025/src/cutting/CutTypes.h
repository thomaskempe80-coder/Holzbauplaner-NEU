#pragma once
#include <cstddef>
#include <string>
#include <vector>

namespace hbp::cutting {

struct CutItem {
  std::wstring material;
  double lengthMm = 0.0;
  double widthMm = 0.0;
  double thicknessMm = 0.0;
  std::size_t quantity = 0;
  std::vector<std::wstring> partIds;
};

inline void SortDescending(double a, double b, double c,
                           double& largest, double& middle, double& smallest) {
  if (a < b) { const double t=a; a=b; b=t; }
  if (b < c) { const double t=b; b=c; c=t; }
  if (a < b) { const double t=a; a=b; b=t; }
  largest=a; middle=b; smallest=c;
}

} // namespace hbp::cutting
