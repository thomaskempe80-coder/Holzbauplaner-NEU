#include "fillet/FilletTool.h"
#include <BRepFilletAPI_MakeFillet.hxx>

namespace hbp::fillet {
bool FilletTool::Activate(const TopoDS_Shape& ownerShape, const TopoDS_Edge& edge) {
  Deactivate();
  if (ownerShape.IsNull() || edge.IsNull()) return false;
  sourceShape_ = ownerShape;
  edge_ = edge;
  active_ = true;
  return true;
}

void FilletTool::Deactivate() noexcept {
  active_ = false;
  sourceShape_.Nullify();
  edge_.Nullify();
  finishedShape_.Nullify();
}

bool FilletTool::CommitRadius(double radiusMm) {
  if (!active_ || sourceShape_.IsNull() || edge_.IsNull() || radiusMm <= 0.0) return false;
  BRepFilletAPI_MakeFillet builder(sourceShape_);
  builder.Add(radiusMm, edge_);
  builder.Build();
  if (!builder.IsDone()) return false;
  const TopoDS_Shape result = builder.Shape();
  if (result.IsNull()) return false;
  finishedShape_ = result;
  active_ = false;
  return true;
}

TopoDS_Shape FilletTool::TakeFinishedShape() {
  TopoDS_Shape result = finishedShape_;
  finishedShape_.Nullify();
  return result;
}

std::wstring FilletTool::StatusText() const {
  return active_ ? L"Rundung: Radius in mm eingeben → Enter" : L"Rundung";
}
}
