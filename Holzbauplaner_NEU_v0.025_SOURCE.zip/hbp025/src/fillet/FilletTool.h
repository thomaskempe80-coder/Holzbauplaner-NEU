#pragma once
#include <TopoDS_Shape.hxx>
#include <TopoDS_Edge.hxx>
#include <string>

namespace hbp::fillet {
class FilletTool {
public:
  bool Activate(const TopoDS_Shape& ownerShape, const TopoDS_Edge& edge);
  void Deactivate() noexcept;
  bool IsActive() const noexcept { return active_; }
  bool CommitRadius(double radiusMm);
  const TopoDS_Shape& SourceShape() const noexcept { return sourceShape_; }
  TopoDS_Shape TakeFinishedShape();
  std::wstring StatusText() const;
private:
  bool active_ = false;
  TopoDS_Shape sourceShape_;
  TopoDS_Edge edge_;
  TopoDS_Shape finishedShape_;
};
}
