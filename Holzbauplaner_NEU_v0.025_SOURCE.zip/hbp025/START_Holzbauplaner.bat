@echo off
set "APP=%LOCALAPPDATA%\Holzbauplaner\versions\v0.025\Holzbauplaner.exe"
if not exist "%APP%" (
  echo Holzbauplaner v0.025 ist nicht installiert.
  echo Bitte zuerst INSTALL_Holzbauplaner.bat starten.
  pause
  exit /b 2
)
start "" "%APP%"
