HOLZBAUPLANER NEU - v0.025
============================

STAND IM GESAMTPLAN
-------------------
Version 18 von derzeit ca. 18 geplanten Kernversionen.
Der erste Neuaufbau-Zyklus ist damit technisch abgeschlossen.

GERADE VORHER FERTIG
--------------------
v0.017 brachte Speichern/Laden und den zentralen Undo/Redo-Verlauf.

ZIEL DIESER VERSION
-------------------
Bedienung, Gesamthaertung und Regression:
- aktive Werkzeuge links deutlich hervorheben
- aktives Werkzeug rechts klar anzeigen
- aktive Ausgabeansichten oben markieren
- ESC-Abbruch sichtbar in der Statusleiste nennen
- alle bisherigen Modulgrenzen erneut statisch pruefen
- Versionsnummern in Programm, CMake, BAT und README angleichen
- Gesamt-Pruefliste fuer den ersten praktischen Windows-Test beilegen

OBERFLAECHE
-----------
- weisse Arbeitsflaeche
- schmale Werkzeugleiste links
- kompakte Funktionsleiste oben
- Eigenschaften-/Materialbereich rechts
- aktives Werkzeug wird blau hervorgehoben
- Bleistift und Loeschen behalten ihre eigenen Werkzeugcursor

BEDIENUNG
---------
LMB = Auswaehlen / Zeichnen
RMB gedrueckt = Orbit
MMB gedrueckt = Pan
Mausrad = Zoom
ESC = aktiven Zeichenschritt abbrechen
Strg+S = Speichern
Strg+O = Oeffnen
Strg+Z = Undo
Strg+Y = Redo

BAT-ABLAUF
----------
Der Benutzerweg bleibt BAT-basiert: INSTALL_Holzbauplaner.bat bzw. START_Holzbauplaner.bat.
Die BAT kuemmert sich um den Startpfad; der Nutzer soll keine Entwicklerbefehle eingeben.

WICHTIG ZUM PRAKTISCHEN TEST
---------------------------
Die beiliegende REGRESSION_V018_CHECKLIST.txt beschreibt den ersten kompletten Praxistest.
Erst nach diesem Praxistest gelten die Werkzeuge als praktisch bestaetigt.

NAECHSTER SCHRITT
----------------
Kein automatischer Sprung auf v0.019. Nach dem Praxistest werden Beobachtungen gesammelt.
Erst nach ausdruecklicher Freigabe des Nutzers wird eine weitere Version begonnen.
