@echo off
setlocal
set "VERSION=0.025"
set "SOURCE=%~dp0..\dist"
set "TARGET=%LOCALAPPDATA%\Holzbauplaner\versions\v%VERSION%"

if not exist "%SOURCE%\Holzbauplaner.exe" (
  echo.
  echo FEHLER: Holzbauplaner.exe fehlt im dist-Ordner.
  echo Diese ZIP ist noch kein freigegebener Windows-Testbuild.
  echo.
  pause
  exit /b 2
)

if not exist "%TARGET%" mkdir "%TARGET%"
xcopy "%SOURCE%\*" "%TARGET%\" /E /I /Y >nul
if errorlevel 1 (
  echo Installation fehlgeschlagen.
  pause
  exit /b 3
)

echo Installation erfolgreich: %TARGET%
start "" "%TARGET%\Holzbauplaner.exe"
endlocal
