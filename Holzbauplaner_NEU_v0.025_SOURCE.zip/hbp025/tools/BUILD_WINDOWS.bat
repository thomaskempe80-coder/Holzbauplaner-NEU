@echo off
setlocal
if "%OCCT_DIR%"=="" (
  echo OCCT_DIR ist nicht gesetzt. Dieser Build-Schritt ist fuer die Entwicklungsumgebung bestimmt.
  exit /b 2
)
cmake -S "%~dp0.." -B "%~dp0..\build" -A x64 -DOpenCASCADE_DIR="%OCCT_DIR%"
if errorlevel 1 exit /b 3
cmake --build "%~dp0..\build" --config Release
if errorlevel 1 exit /b 4
if not exist "%~dp0..\dist" mkdir "%~dp0..\dist"
copy /Y "%~dp0..\build\bin\Release\Holzbauplaner.exe" "%~dp0..\dist\Holzbauplaner.exe" >nul
endlocal
